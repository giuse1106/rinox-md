//Crediti by Gabs


let running = false; 

let handler = async (m, { conn, groupMetadata, participants, isBotAdmin, command }) => {
    if (!isBotAdmin) {
        return m.reply("⚠️ Il bot deve essere amministratore per eseguire questo comando.");
    }

    let ps = participants.map(u => u.id).filter(v => v !== conn.user.jid); 
    if (ps.length < 5) {
        return m.reply("⚠️ Ci devono essere almeno 10 membri nel gruppo per eseguire questo comando.");
    }

    const delay = time => new Promise(res => setTimeout(res, time));
    running = true; 

    if (command === 'confu') {
        m.reply("⚙️ Inizio del caos...");

        while (running) {
            try {
                let selectedUsers = ps.sort(() => Math.random() - 0.5).slice(0, 10); 
                
                m.reply("👥 Promuovo questi utenti ad amministratori: " + selectedUsers.map(u => `@${u.split('@')[0]}`).join(', '), null, { mentions: selectedUsers });

                
                await conn.groupParticipantsUpdate(m.chat, selectedUsers, 'promote');
                await delay(1000); // 

                m.reply("🔻 Retrocedo gli stessi utenti: " + selectedUsers.map(u => `@${u.split('@')[0]}`).join(', '), null, { mentions: selectedUsers });

                
                await conn.groupParticipantsUpdate(m.chat, selectedUsers, 'demote');
                await delay(2000); 
            } catch (err) {
                console.error(err);
                m.reply("⚠️ Si è verificato un errore: " + err.message);
                break;
            }
        }

        m.reply("⏹️ La confusione è stata interrotta.");
    } else if (command === 'smettila') {
        running = false; // Ferma il ciclo
        m.reply("🛑 Eh vabene, smetto di fare confusione");
    }
};

handler.command = /^(confu|smettila)$/i;
handler.group = true; 
handler.rowner = true; 
handler.botAdmin = true; 

export default handler;
