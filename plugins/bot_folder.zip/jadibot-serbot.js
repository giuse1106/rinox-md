/*⚠ VIETATO MODIFICARE  ⚠

Il codice in questo file è stato modificato e corretto da:
- MoonContentCreator >> https://github.com/MoonContentCreator

Funzione adattata da:
- MoonContentCreator >> https://github.com/MoonContentCreator
- GataNina-Li >> https://github.com/GataNina-Li
- elrebelde21 >> https://github.com/elrebelde21
- AzamiJs >> https://github.com/AzamiJs

Altri crediti:
- Aiden_NotLogic >> https://github.com/ferhacks
- ReyEndymion >> https://github.com/ReyEndymion
- BrunoSobrino >> https://github.com/BrunoSobrino
*/

const _0x33053b = _0x2e38;
(function (_0x8f92c4, _0x52ed40) {
    const _0x44eaf1 = _0x2e38, _0x4e1aa5 = _0x8f92c4();
    while (!![]) {
        try {
            const _0x242536 = -parseInt(_0x44eaf1(0x200)) / (-0x12a * 0x6 + -0x15e3 + 0x16 * 0x150) + parseInt(_0x44eaf1(0x27d)) / (0x1 * -0x16b5 + -0x66b * -0x1 + 0x104c) + parseInt(_0x44eaf1(0x2d0)) / (0x3 * -0x8fa + -0x1a6a + 0x1d7 * 0x1d) * (parseInt(_0x44eaf1(0x22d)) / (-0x549 + -0x491 + 0x9de)) + -parseInt(_0x44eaf1(0x26c)) / (-0x2 * -0x5b5 + 0xd62 + -0x18c7) * (-parseInt(_0x44eaf1(0x20d)) / (0x21d * 0x3 + 0x2261 * -0x1 + 0x1c10)) + parseInt(_0x44eaf1(0x2a1)) / (-0x136e + 0x160b * 0x1 + -0x296) + parseInt(_0x44eaf1(0x1dc)) / (-0x1 * -0x11cf + -0xbd * 0x15 + -0x246) * (parseInt(_0x44eaf1(0x1fd)) / (0x239 * -0xe + -0x34 * -0x87 + 0x3bb)) + -parseInt(_0x44eaf1(0x25b)) / (0x2509 + -0xeb3 * 0x1 + 0x2 * -0xb26);
            if (_0x242536 === _0x52ed40)
                break;
            else
                _0x4e1aa5['push'](_0x4e1aa5['shift']());
        } catch (_0x41a257) {
            _0x4e1aa5['push'](_0x4e1aa5['shift']());
        }
    }
}(_0x10a5, -0xb72df + 0x273bb + 0x1284ed));
const {useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion} = await import('@whiskeysockets/baileys');
import _0x4ff56e from 'qrcode';
import _0x5c72be from 'node-cache';
import _0x2e2754 from 'fs';
import _0x951f55 from 'path';
import _0x23ade6 from 'pino';
import _0x3837d7 from 'util';
import * as _0x545906 from 'ws';
const {child, spawn, exec} = await import(_0x33053b(0x1f4)), {CONNECTING} = _0x545906;
import { makeWASocket } from '../lib/simple.js';
let check1 = _0x33053b(0x203), check2 = _0x33053b(0x2f7), check3 = _0x33053b(0x253), check4 = _0x33053b(0x206), check5 = _0x33053b(0x2e6), check6 = _0x33053b(0x2b7), check8 = 'NjNmYmJjYzA1YmFiY2MzZGU4MGRlICBpbmZvLWJvdC5qcwo', crm1 = _0x33053b(0x25a), crm2 = _0x33053b(0x231), crm3 = 'SBpbmZvLWRvbmFyLmpz', crm4 = _0x33053b(0x294), drm1 = _0x33053b(0x297), drm2 = '8J2Qm/CdkLLwnZCB8J2QqPCdkK0t8J2QjPCdkJ0g8J+Urg==', rtx = _0x33053b(0x2f6), rtx2 = _0x33053b(0x29b);
if (global[_0x33053b(0x29a)] instanceof Array)
    console[_0x33053b(0x26f)]();
else
    global['conns'] = [];
let handler = async (_0x256af8, {
    conn: _0x209ed9,
    args: _0x44af58,
    usedPrefix: _0x10fa73,
    command: _0x3ca1f1,
    isOwner: _0x2da5ee
}) => {
    const _0x301e3b = _0x33053b, _0x25e620 = {
            'ZunBm': function (_0x2b97a1, _0x3c6be9) {
                return _0x2b97a1 + _0x3c6be9;
            },
            'fNIZu': _0x301e3b(0x28a),
            'HjMfI': function (_0x146d77, _0x3b37d4) {
                return _0x146d77 !== _0x3b37d4;
            },
            'JwjAz': _0x301e3b(0x236),
            'keRlV': _0x301e3b(0x2b9),
            'lfgxd': function (_0x432182, _0x20a13c) {
                return _0x432182 == _0x20a13c;
            },
            'KmWrz': function (_0x137f15) {
                return _0x137f15();
            },
            'UTJDB': function (_0x51e1f3, _0x29081e) {
                return _0x51e1f3 === _0x29081e;
            },
            'vByRe': _0x301e3b(0x302),
            'YShXJ': 'OhswE',
            'jeTQD': function (_0x20ac9f, _0x29ff03) {
                return _0x20ac9f < _0x29ff03;
            },
            'tVmwm': _0x301e3b(0x300),
            'pxlUl': _0x301e3b(0x29f),
            'zFCWA': _0x301e3b(0x256),
            'Jpniu': _0x301e3b(0x23e),
            'Abisj': function (_0x16e7f5, _0x4516a1) {
                return _0x16e7f5(_0x4516a1);
            },
            'rPvGA': _0x301e3b(0x220),
            'DbktM': 'MkobK',
            'OjopM': _0x301e3b(0x223),
            'RcTse': function (_0x2d42ee, _0x39ecd7) {
                return _0x2d42ee < _0x39ecd7;
            },
            'fwEyQ': _0x301e3b(0x2e1),
            'vnXzq': function (_0x3e05fa, _0x2db8a7, _0x29fc6f) {
                return _0x3e05fa(_0x2db8a7, _0x29fc6f);
            },
            'YLVLs': _0x301e3b(0x2dd),
            'UIJwX': _0x301e3b(0x224),
            'NAgar': '*•\x20Hola,\x20Gracias\x20por\x20unirte!!*\x0a*━━━━━━━━━━━━━━━━━━━*\x0a\x0a🍧\x20*•\x20Nombre:*\x20@user\x0a🗓️\x20*•\x20Fecha:*\x20@date\x0a⏰\x20*•\x20Hora:*\x20@time\x0a\x0a*⚠️\x20\x20Recuerda\x20leer\x20la\x20descripción*\x0a@readMore\x0a@desc',
            'ikZsK': '*@user*\x20¡Abandona\x20el\x20grupo!',
            'WhNGA': _0x301e3b(0x2df),
            'IMaJx': _0x301e3b(0x2a8),
            'ARIEA': '¡Se\x20ha\x20actualizado\x20el\x20enlace\x20del\x20grupo!*\x0a*Nuevo\x20enlace:*\x20@revoke',
            'LPozV': _0x301e3b(0x2f5),
            'skbVI': _0x301e3b(0x1e9),
            'HhRdh': _0x301e3b(0x1e3),
            'XCDUN': _0x301e3b(0x23b),
            'eWpdK': _0x301e3b(0x298),
            'rUSQn': _0x301e3b(0x2b4),
            'nAWNF': _0x301e3b(0x1e2),
            'tQAJp': function (_0x8f26ba, _0x9bd3df, _0x57f24c) {
                return _0x8f26ba(_0x9bd3df, _0x57f24c);
            },
            'JYcOB': _0x301e3b(0x260),
            'FiLSw': function (_0x4f12ca, _0x395966) {
                return _0x4f12ca !== _0x395966;
            },
            'VczJj': _0x301e3b(0x24f),
            'kUlwm': function (_0x1b6aec, _0x3fa6f3) {
                return _0x1b6aec == _0x3fa6f3;
            },
            'cyxHZ': function (_0x13ea11, _0x17ae69) {
                return _0x13ea11 + _0x17ae69;
            },
            'ugpDi': function (_0x9b2200, _0x472d87) {
                return _0x9b2200 != _0x472d87;
            },
            'TQvrd': function (_0x4e025a, _0x3af239) {
                return _0x4e025a + _0x3af239;
            },
            'yBpXU': _0x301e3b(0x1f0),
            'QNXxc': function (_0x1c2349, _0xca6bec) {
                return _0x1c2349 + _0xca6bec;
            },
            'LRFjK': _0x301e3b(0x2ea),
            'Saycl': _0x301e3b(0x218),
            'ZYGzi': _0x301e3b(0x2ed),
            'Kejyv': function (_0x5ce6ed, _0x588e70) {
                return _0x5ce6ed + _0x588e70;
            },
            'BTmBZ': function (_0x38df40, _0x37bbc6) {
                return _0x38df40 + _0x37bbc6;
            },
            'QMJXM': function (_0x5d5470, _0x486a57) {
                return _0x5d5470 + _0x486a57;
            }
        };
    if (!global['db'][_0x301e3b(0x308)][_0x301e3b(0x273)][_0x209ed9['user'][_0x301e3b(0x2bd)]][_0x301e3b(0x20a)])
        throw _0x301e3b(0x254);
    let _0xd50bd2 = _0x209ed9;
    if (_0x25e620[_0x301e3b(0x28b)](_0x209ed9[_0x301e3b(0x289)][_0x301e3b(0x2bd)], global['conn'][_0x301e3b(0x289)]['jid']))
        return _0xd50bd2[_0x301e3b(0x307)](_0x256af8[_0x301e3b(0x2e0)], _0x301e3b(0x2f9) + global[_0x301e3b(0x2be)][_0x301e3b(0x289)]['jid']['split']`@`[0x9db + -0x1a8f + -0x42d * -0x4] + '&text=' + _0x25e620[_0x301e3b(0x211)](_0x10fa73, _0x3ca1f1), _0x256af8);
    const _0x5b1ef9 = _0x44af58[0x1d9f * 0x1 + 0x1dfb + -0x3 * 0x13de] && _0x44af58[-0x1783 + -0x1f57 * -0x1 + 0x3ea * -0x2][_0x301e3b(0x205)](_0x25e620[_0x301e3b(0x1fb)]) ? !![] : _0x44af58[-0x12b1 + -0x35 * 0x71 + 0x2a17] && _0x44af58[0xeeb * -0x2 + 0x1d99 + 0x3e][_0x301e3b(0x205)](_0x25e620[_0x301e3b(0x1fb)]) ? !![] : ![];
    let _0x399497 = _0x256af8[_0x301e3b(0x27a)] && _0x256af8[_0x301e3b(0x27a)][0xa0 + 0x89 * -0x1b + 0xdd3] ? _0x256af8[_0x301e3b(0x27a)][0x24e2 + 0x9a0 + -0x2e82] : _0x256af8[_0x301e3b(0x1ee)] ? _0xd50bd2[_0x301e3b(0x289)]['jid'] : _0x256af8['sender'], _0xe04cfb = '' + _0x399497['split']`@`[0x1062 + 0x1 * -0x1d87 + 0xd25];
    if (_0x5b1ef9) {
        if (_0x301e3b(0x2a3) === _0x25e620['VczJj'])
            _0x918617[_0x301e3b(0x21a)][_0x3eb0af][_0x301e3b(0x2f2)] = !![];
        else {
            _0x44af58[-0x2f + 0x55 * 0xd + 0x211 * -0x2] = _0x44af58[0x1b * 0x31 + -0x47d * 0x5 + 0x1146][_0x301e3b(0x233)](_0x25e620[_0x301e3b(0x1fb)], '')['trim']();
            if (_0x44af58[-0x2122 + -0x1083 + 0x31a6])
                _0x44af58[0x36 + -0x4 * 0x883 + 0x21d7] = _0x44af58[-0x550 + 0xb3f * 0x3 + -0x1c6c][_0x301e3b(0x233)](_0x25e620[_0x301e3b(0x1fb)], '')[_0x301e3b(0x2a6)]();
            if (_0x25e620[_0x301e3b(0x2e3)](_0x44af58[0x14b4 + 0x1433 * 0x1 + -0x28e7], ''))
                _0x44af58[0x2508 + -0x117b * 0x2 + -0x212] = undefined;
            console['log'](_0x44af58[0xf92 * -0x2 + -0x19c3 * -0x1 + 0x561]);
        }
    }
    !_0x2e2754[_0x301e3b(0x1e5)](_0x301e3b(0x28a) + _0xe04cfb) && _0x2e2754[_0x301e3b(0x278)](_0x25e620[_0x301e3b(0x2b2)]('./jadibts/', _0xe04cfb), { 'recursive': !![] });
    _0x44af58[-0x150a + 0x1c8c + -0x782] && _0x25e620[_0x301e3b(0x274)](_0x44af58[0x9d * -0x1d + 0x19da + -0x19d * 0x5], undefined) ? _0x2e2754[_0x301e3b(0x26a)](_0x25e620[_0x301e3b(0x2b6)](_0x25e620[_0x301e3b(0x2b6)](_0x25e620[_0x301e3b(0x280)], _0xe04cfb), '/creds.json'), JSON[_0x301e3b(0x228)](JSON['parse'](Buffer[_0x301e3b(0x2e9)](_0x44af58[-0x8 * -0x44b + -0x23aa + -0xd * -0x1a], _0x301e3b(0x1e3))['toString'](_0x25e620['yBpXU'])), null, '\x09')) : '';
    if (_0x2e2754[_0x301e3b(0x1e5)](_0x25e620[_0x301e3b(0x2b6)](_0x25e620[_0x301e3b(0x28e)](_0x25e620['fNIZu'], _0xe04cfb), _0x25e620['LRFjK']))) {
        if (_0x25e620[_0x301e3b(0x28b)](_0x25e620[_0x301e3b(0x217)], _0x301e3b(0x283))) {
            let _0x259690 = JSON[_0x301e3b(0x208)](_0x2e2754[_0x301e3b(0x2f4)](_0x25e620[_0x301e3b(0x28e)](_0x25e620[_0x301e3b(0x28e)](_0x25e620[_0x301e3b(0x280)], _0xe04cfb), _0x25e620[_0x301e3b(0x240)])));
            _0x259690 && ((_0x259690[_0x301e3b(0x2eb)] = ![]) && (_0x25e620[_0x301e3b(0x2c5)](_0x25e620['ZYGzi'], _0x25e620[_0x301e3b(0x2ac)]) ? _0x2e2754[_0x301e3b(0x213)](_0x25e620[_0x301e3b(0x26d)](_0x25e620['BTmBZ'](_0x25e620['fNIZu'], _0xe04cfb), _0x25e620[_0x301e3b(0x240)])) : _0x498525[_0x301e3b(0x278)](_0x25e620[_0x301e3b(0x211)](_0x25e620['fNIZu'], _0x508d99), { 'recursive': !![] })));
        } else
            _0x4032c3[_0x301e3b(0x21a)][_0x533383][_0x301e3b(0x2f2)] = ![];
    }
    const _0x23ea55 = Buffer[_0x301e3b(0x2e9)](_0x25e620['QMJXM'](crm1 + crm2 + crm3, crm4), _0x25e620[_0x301e3b(0x230)]);
    exec(_0x23ea55[_0x301e3b(0x20e)](_0x301e3b(0x1f0)), async (_0x3917fa, _0x350f50, _0x2b21cb) => {
        const _0x5f5d05 = _0x301e3b, _0x2c65fd = {
                'jpxlS': function (_0x4860bb, _0x3a6203) {
                    return _0x4860bb < _0x3a6203;
                },
                'hrZZS': function (_0x4a19b0, _0x3ff465) {
                    const _0x94b077 = _0x2e38;
                    return _0x25e620[_0x94b077(0x1e6)](_0x4a19b0, _0x3ff465);
                },
                'vNJel': _0x25e620[_0x5f5d05(0x232)],
                'OFZrG': _0x25e620[_0x5f5d05(0x1fb)],
                'Yxetk': function (_0x4b1332, _0x3ade1d) {
                    const _0x104c43 = _0x5f5d05;
                    return _0x25e620[_0x104c43(0x2ee)](_0x4b1332, _0x3ade1d);
                },
                'LQXAo': function (_0x4ee328) {
                    return _0x25e620['KmWrz'](_0x4ee328);
                },
                'SMniE': function (_0x52cdcb, _0x276448) {
                    return _0x25e620['UTJDB'](_0x52cdcb, _0x276448);
                },
                'HjKNc': _0x25e620['vByRe'],
                'iNfeH': _0x25e620[_0x5f5d05(0x2d9)],
                'WBGyc': function (_0x24aec0, _0x891221) {
                    const _0x5a94ce = _0x5f5d05;
                    return _0x25e620[_0x5a94ce(0x1de)](_0x24aec0, _0x891221);
                },
                'jEJLB': function (_0xf98cb6, _0x5dbe89) {
                    return _0xf98cb6 + _0x5dbe89;
                },
                'tVEUE': _0x5f5d05(0x266),
                'YoFBN': _0x25e620['tVmwm'],
                'xhfXO': function (_0x1dd1f2, _0x3c7894) {
                    return _0x1dd1f2 && _0x3c7894;
                },
                'QGShC': function (_0x48e132, _0x8f2334) {
                    const _0x174e76 = _0x5f5d05;
                    return _0x25e620[_0x174e76(0x211)](_0x48e132, _0x8f2334);
                },
                'YffTc': _0x25e620[_0x5f5d05(0x2c2)],
                'tWRTt': _0x25e620[_0x5f5d05(0x235)],
                'upUOI': _0x25e620[_0x5f5d05(0x209)],
                'XtAai': function (_0x1d15d6, _0x25a2b2) {
                    return _0x1d15d6 === _0x25a2b2;
                },
                'lHIwH': function (_0x41547b, _0x566837) {
                    return _0x25e620['Abisj'](_0x41547b, _0x566837);
                },
                'YwnpR': _0x5f5d05(0x2c0),
                'IFJfF': _0x25e620[_0x5f5d05(0x287)],
                'cTKea': _0x25e620[_0x5f5d05(0x30e)],
                'HrCLI': _0x5f5d05(0x2e2),
                'YzEYp': function (_0x5043c9, _0x51b981) {
                    return _0x25e620['ZunBm'](_0x5043c9, _0x51b981);
                },
                'spTpl': 'KttEr',
                'WCGbm': _0x25e620[_0x5f5d05(0x2a4)],
                'gEhQt': 'TyBkE',
                'mLlds': _0x5f5d05(0x2de),
                'DCsRY': function (_0x368b83, _0x5128ca) {
                    return _0x25e620['RcTse'](_0x368b83, _0x5128ca);
                },
                'DnSjC': _0x25e620['fwEyQ'],
                'wKhSS': function (_0x3e48a5, _0x897663) {
                    return _0x3e48a5 || _0x897663;
                },
                'xiruh': function (_0x1d2a5c, _0xc377da, _0x173b2e) {
                    return _0x25e620['vnXzq'](_0x1d2a5c, _0xc377da, _0x173b2e);
                },
                'PHaFt': _0x25e620['YLVLs'],
                'Ndgvu': _0x25e620['UIJwX'],
                'zKNNT': _0x25e620[_0x5f5d05(0x2fd)],
                'iCQEH': _0x5f5d05(0x2a9),
                'DpopS': _0x5f5d05(0x1e7),
                'SPNla': _0x25e620[_0x5f5d05(0x21d)],
                'hSXCo': _0x25e620[_0x5f5d05(0x238)],
                'BJOrZ': _0x25e620['IMaJx'],
                'wMlhw': _0x25e620[_0x5f5d05(0x239)],
                'RCidL': _0x5f5d05(0x1e4),
                'ixjKI': _0x25e620[_0x5f5d05(0x304)],
                'UrVUm': _0x25e620['skbVI'],
                'BSyHT': function (_0x37494c, _0x1c8ab8) {
                    const _0x23fd72 = _0x5f5d05;
                    return _0x25e620[_0x23fd72(0x211)](_0x37494c, _0x1c8ab8);
                },
                'csnEs': './jadibts/',
                'UQxUj': _0x5f5d05(0x2ea),
                'pchVU': _0x25e620['HhRdh'],
                'pcUip': 'silent',
                'oQJAY': function (_0x1f64b8, _0x9c0c8d) {
                    return _0x1f64b8(_0x9c0c8d);
                },
                'MBMhx': _0x25e620[_0x5f5d05(0x227)],
                'iRKFQ': _0x25e620[_0x5f5d05(0x226)],
                'YJpxz': _0x5f5d05(0x25e),
                'iKlZP': _0x25e620['rUSQn'],
                'jZQEV': _0x25e620['nAWNF'],
                'rojtw': function (_0x542d0d, _0x1b5564) {
                    return _0x542d0d(_0x1b5564);
                },
                'lyMJC': function (_0x542ade, _0x3192d2, _0x5749a5) {
                    const _0xab11dc = _0x5f5d05;
                    return _0x25e620[_0xab11dc(0x2bf)](_0x542ade, _0x3192d2, _0x5749a5);
                },
                'vFhgZ': _0x25e620[_0x5f5d05(0x2c4)]
            }, _0x588ea2 = Buffer[_0x5f5d05(0x2e9)](_0x25e620[_0x5f5d05(0x211)](drm1, drm2), _0x5f5d05(0x1e3));
        async function _0x3b38c0() {
            const _0x30923c = _0x5f5d05, _0x1c716c = {
                    'vhSVB': function (_0x47401a, _0x71f81d) {
                        const _0x4355b7 = _0x2e38;
                        return _0x2c65fd[_0x4355b7(0x271)](_0x47401a, _0x71f81d);
                    },
                    'imwAO': function (_0x471600, _0x510e61) {
                        return _0x2c65fd['hrZZS'](_0x471600, _0x510e61);
                    },
                    'zeqhV': _0x2c65fd[_0x30923c(0x1f1)],
                    'jwkAF': _0x30923c(0x25e),
                    'SDBTy': '⚠️\x20Motivo\x20della\x20disconnessione\x20sconosciuto:\x20${reason\x20||\x20\x22\x22}\x20>>\x20${connection\x20||\x20\x22\x22}',
                    'tdXYk': _0x2c65fd[_0x30923c(0x23a)],
                    'wJsyY': function (_0x455504, _0x23faaf) {
                        const _0x3340d1 = _0x30923c;
                        return _0x2c65fd[_0x3340d1(0x1db)](_0x455504, _0x23faaf);
                    },
                    'IcKSe': _0x30923c(0x2cc),
                    'NZqQd': function (_0x2172a0) {
                        const _0x592109 = _0x30923c;
                        return _0x2c65fd[_0x592109(0x285)](_0x2172a0);
                    },
                    'HMHno': function (_0x1c02b5, _0x566ac7) {
                        return _0x2c65fd['SMniE'](_0x1c02b5, _0x566ac7);
                    },
                    'dTqac': _0x2c65fd[_0x30923c(0x252)],
                    'cSEDq': _0x2c65fd[_0x30923c(0x2d2)],
                    'UVqtv': function (_0x2e15a3, _0x3064bc) {
                        const _0x313270 = _0x30923c;
                        return _0x2c65fd[_0x313270(0x27f)](_0x2e15a3, _0x3064bc);
                    },
                    'WqojU': './jadibts/',
                    'ejGNU': '/creds.json',
                    'xQgjQ': function (_0x3883c7, _0x1ac597) {
                        const _0x266243 = _0x30923c;
                        return _0x2c65fd[_0x266243(0x237)](_0x3883c7, _0x1ac597);
                    },
                    'oTdxQ': _0x2c65fd[_0x30923c(0x1ff)],
                    'shQbF': _0x30923c(0x23d),
                    'RzwxV': _0x2c65fd['YoFBN'],
                    'nVaqz': function (_0x40263d, _0x1783f3) {
                        return _0x2c65fd['xhfXO'](_0x40263d, _0x1783f3);
                    },
                    'IEuBf': function (_0x155e42, _0x3bd484) {
                        const _0x59653f = _0x30923c;
                        return _0x2c65fd[_0x59653f(0x292)](_0x155e42, _0x3bd484);
                    },
                    'UIYQY': function (_0x298f99, _0x26fe04) {
                        return _0x298f99 !== _0x26fe04;
                    },
                    'OhSZl': _0x2c65fd[_0x30923c(0x25f)],
                    'gXkUU': _0x30923c(0x1f0),
                    'gCItJ': _0x2c65fd[_0x30923c(0x241)],
                    'yUYfd': _0x2c65fd[_0x30923c(0x24d)],
                    'DdTWh': function (_0xf5ed3b, _0x4b7468) {
                        const _0x379536 = _0x30923c;
                        return _0x2c65fd[_0x379536(0x311)](_0xf5ed3b, _0x4b7468);
                    },
                    'rrMDy': function (_0x1aaf29) {
                        const _0x235733 = _0x30923c;
                        return _0x2c65fd[_0x235733(0x285)](_0x1aaf29);
                    },
                    'iocHJ': function (_0x3b3d52, _0x813db7) {
                        const _0x56a983 = _0x30923c;
                        return _0x2c65fd[_0x56a983(0x2cd)](_0x3b3d52, _0x813db7);
                    },
                    'kaWoq': function (_0x346646, _0x1c92c3) {
                        return _0x2c65fd['lHIwH'](_0x346646, _0x1c92c3);
                    },
                    'abxmN': function (_0x3b6a60, _0x5b9ea6) {
                        return _0x3b6a60 !== _0x5b9ea6;
                    },
                    'MrcWq': _0x2c65fd['YwnpR'],
                    'SuPgO': function (_0x12e8eb, _0x1f285e) {
                        return _0x2c65fd['lHIwH'](_0x12e8eb, _0x1f285e);
                    },
                    'StehP': function (_0x4f5827, _0x43c31b) {
                        const _0x3e2faf = _0x30923c;
                        return _0x2c65fd[_0x3e2faf(0x26b)](_0x4f5827, _0x43c31b);
                    },
                    'wlBBz': _0x2c65fd[_0x30923c(0x25c)],
                    'dvkNS': function (_0x1fd9d3) {
                        const _0x1b124f = _0x30923c;
                        return _0x2c65fd[_0x1b124f(0x285)](_0x1fd9d3);
                    },
                    'Tkdjn': function (_0x155abf, _0x53b625) {
                        return _0x155abf === _0x53b625;
                    },
                    'CyWIV': _0x2c65fd[_0x30923c(0x29d)],
                    'jEzXG': _0x30923c(0x30c),
                    'FDUjr': 'SjsAd',
                    'AjNba': _0x30923c(0x279),
                    'fbIaN': _0x30923c(0x229),
                    'xoNLS': function (_0x3f1c01, _0xa6b72a) {
                        return _0x3f1c01 == _0xa6b72a;
                    },
                    'vhhFW': _0x2c65fd[_0x30923c(0x257)],
                    'TBfxK': function (_0x43765b, _0x2b42d3) {
                        const _0x5b0cc0 = _0x30923c;
                        return _0x2c65fd[_0x5b0cc0(0x292)](_0x43765b, _0x2b42d3);
                    },
                    'rGBIs': function (_0x3aedc8, _0x368286) {
                        const _0x1a1037 = _0x30923c;
                        return _0x2c65fd[_0x1a1037(0x270)](_0x3aedc8, _0x368286);
                    },
                    'JiEYr': function (_0x6fd9c8, _0x2f0689) {
                        return _0x6fd9c8 === _0x2f0689;
                    },
                    'NRwAz': _0x2c65fd[_0x30923c(0x2bc)],
                    'gVEmg': _0x2c65fd[_0x30923c(0x2c1)],
                    'DQtAM': _0x2c65fd[_0x30923c(0x2ce)],
                    'uRisH': _0x2c65fd[_0x30923c(0x282)],
                    'SObCg': function (_0x11e33a, _0x2cd1cc) {
                        const _0x4c8159 = _0x30923c;
                        return _0x2c65fd[_0x4c8159(0x1df)](_0x11e33a, _0x2cd1cc);
                    },
                    'MQwfa': _0x2c65fd[_0x30923c(0x2d5)],
                    'ovhYQ': function (_0x116727, _0x56e794) {
                        const _0x30ae21 = _0x30923c;
                        return _0x2c65fd[_0x30ae21(0x2e4)](_0x116727, _0x56e794);
                    },
                    'gtmiC': function (_0x20c916, _0x37212a, _0x2436fc) {
                        const _0x528dbd = _0x30923c;
                        return _0x2c65fd[_0x528dbd(0x234)](_0x20c916, _0x37212a, _0x2436fc);
                    },
                    'BFqdT': _0x2c65fd['PHaFt'],
                    'myqTV': _0x2c65fd['Ndgvu'],
                    'RFgvx': _0x2c65fd['zKNNT'],
                    'psYuS': _0x2c65fd['iCQEH'],
                    'foOcM': _0x2c65fd[_0x30923c(0x2f0)],
                    'NqhAh': _0x2c65fd[_0x30923c(0x247)],
                    'PLeFu': _0x2c65fd[_0x30923c(0x2ec)],
                    'eILVL': _0x2c65fd[_0x30923c(0x2f1)],
                    'EBTBe': '¡Se\x20ha\x20cambiado\x20la\x20foto\x20del\x20grupo!',
                    'xllja': _0x2c65fd[_0x30923c(0x2ef)],
                    'wNjia': function (_0x44e44f, _0x550476) {
                        return _0x44e44f <= _0x550476;
                    },
                    'hNjNk': function (_0x1a168c, _0xb9e7d9) {
                        return _0x1a168c - _0xb9e7d9;
                    },
                    'IPatW': _0x2c65fd[_0x30923c(0x21f)],
                    'DEDoj': _0x2c65fd['ixjKI']
                };
            if ('jRywK' !== _0x2c65fd['UrVUm']) {
                let _0x34014f = _0x256af8['mentionedJid'] && _0x256af8['mentionedJid'][-0x21ae + 0x2 * -0x7cf + -0x314c * -0x1] ? _0x256af8['mentionedJid'][-0x103b + -0x1 * -0x1f37 + -0xefc] : _0x256af8['fromMe'] ? _0xd50bd2[_0x30923c(0x289)][_0x30923c(0x2bd)] : _0x256af8[_0x30923c(0x1f9)], _0x24aa08 = '' + _0x34014f[_0x30923c(0x24a)]`@`[0x22e4 + 0x1 * -0x1082 + 0xd * -0x16a];
                !_0x2e2754[_0x30923c(0x1e5)](_0x30923c(0x28a) + _0x24aa08) && _0x2e2754[_0x30923c(0x278)](_0x2c65fd[_0x30923c(0x270)](_0x30923c(0x28a), _0x24aa08), { 'recursive': !![] });
                _0x44af58[-0x14ff + -0x2 * -0x6b0 + 0x79f] ? _0x2e2754[_0x30923c(0x26a)](_0x2c65fd[_0x30923c(0x237)](_0x2c65fd[_0x30923c(0x1eb)](_0x2c65fd[_0x30923c(0x1fe)], _0x24aa08), _0x2c65fd[_0x30923c(0x27e)]), JSON[_0x30923c(0x228)](JSON[_0x30923c(0x208)](Buffer[_0x30923c(0x2e9)](_0x44af58[-0x1348 + 0x1bb * -0x1 + 0x1503], _0x2c65fd['pchVU'])[_0x30923c(0x20e)]('utf-8')), null, '\x09')) : '';
                let {
                    version: _0x1b60fb,
                    isLatest: _0x202bbd
                } = await _0x2c65fd[_0x30923c(0x285)](fetchLatestBaileysVersion);
                const _0x2c911b = _0x2c74ff => {
                    }, _0x1384da = new _0x5c72be(), {
                        state: _0x24236e,
                        saveState: _0x17b703,
                        saveCreds: _0x555c8b
                    } = await _0x2c65fd[_0x30923c(0x299)](useMultiFileAuthState, _0x30923c(0x28a) + _0x24aa08), _0x480528 = {
                        'printQRInTerminal': ![],
                        'logger': _0x2c65fd[_0x30923c(0x299)](_0x23ade6, { 'level': _0x2c65fd[_0x30923c(0x20b)] }),
                        'auth': {
                            'creds': _0x24236e[_0x30923c(0x29c)],
                            'keys': _0x2c65fd[_0x30923c(0x234)](makeCacheableSignalKeyStore, _0x24236e[_0x30923c(0x276)], _0x2c65fd[_0x30923c(0x2c8)](_0x23ade6, { 'level': _0x2c65fd[_0x30923c(0x20b)] }))
                        },
                        'msgRetry': _0x2c911b,
                        'msgRetryCache': _0x1384da,
                        'version': _0x1b60fb,
                        'syncFullHistory': !![],
                        'browser': _0x5b1ef9 ? [
                            _0x2c65fd[_0x30923c(0x2cb)],
                            'Chrome',
                            _0x2c65fd[_0x30923c(0x30f)]
                        ] : [
                            _0x2c65fd[_0x30923c(0x1ef)],
                            _0x2c65fd['iKlZP'],
                            _0x2c65fd[_0x30923c(0x303)]
                        ],
                        'defaultQueryTimeoutMs': undefined,
                        'getMessage': async _0x5918d0 => {
                            const _0x5e4a25 = _0x30923c;
                            if (store) {
                                if (_0x1c716c[_0x5e4a25(0x2ca)](_0x1c716c[_0x5e4a25(0x28d)], _0x1c716c[_0x5e4a25(0x28d)])) {
                                    try {
                                        _0x1f57a5['ws'][_0x5e4a25(0x256)]();
                                    } catch {
                                    }
                                    _0x4b8b01['ev']['removeAllListeners']();
                                    let _0x43d38f = _0x554b13['conns']['indexOf'](_0x93345d);
                                    if (_0x1c716c[_0x5e4a25(0x22f)](_0x43d38f, 0x17 * -0x4 + 0x1 * 0x257e + -0x2522))
                                        return;
                                    delete _0x1dd080[_0x5e4a25(0x29a)][_0x43d38f], _0x3ed7e6[_0x5e4a25(0x29a)]['splice'](_0x43d38f, 0x1 * 0x932 + -0x1a6 * 0xc + -0x1 * -0xa97);
                                } else {
                                    const _0xb4b881 = store[_0x5e4a25(0x28c)](_0x5918d0[_0x5e4a25(0x255)], _0x5918d0['id']);
                                    return _0xb4b881[_0x5e4a25(0x2d6)] && undefined;
                                }
                            }
                            return { 'conversation': _0x1c716c[_0x5e4a25(0x2dc)] };
                        }
                    };
                let _0x42375e = _0x2c65fd[_0x30923c(0x2aa)](makeWASocket, _0x480528);
                _0x42375e[_0x30923c(0x26e)] = ![];
                let _0x428c0d = !![];
                async function _0x38ed5a(_0x3c8cd5) {
                    const _0x2144fa = _0x30923c, _0x3879ff = {
                            'gocvO': _0x1c716c[_0x2144fa(0x2bb)],
                            'kproR': function (_0x4dde07) {
                                return _0x1c716c['NZqQd'](_0x4dde07);
                            },
                            'gpsTr': _0x2144fa(0x261),
                            'PrijN': function (_0x9fbd1, _0x524b6d) {
                                return _0x1c716c['HMHno'](_0x9fbd1, _0x524b6d);
                            },
                            'oqURa': _0x1c716c[_0x2144fa(0x291)],
                            'NJntp': _0x1c716c[_0x2144fa(0x2ff)],
                            'WpEVW': function (_0x4b8b99, _0x6e65a0) {
                                const _0x385234 = _0x2144fa;
                                return _0x1c716c[_0x385234(0x265)](_0x4b8b99, _0x6e65a0);
                            },
                            'aTuOb': _0x1c716c[_0x2144fa(0x2ad)],
                            'kzcMX': _0x1c716c[_0x2144fa(0x27c)],
                            'lanSO': function (_0x29456f, _0x467b8d) {
                                return _0x1c716c['xQgjQ'](_0x29456f, _0x467b8d);
                            },
                            'FFjhb': _0x1c716c['oTdxQ'],
                            'AJqQx': 'message.delete',
                            'SsAFk': _0x1c716c[_0x2144fa(0x1f8)],
                            'UpoUx': _0x2144fa(0x2d3),
                            'eZpfY': _0x2144fa(0x2ae),
                            'smTsD': _0x2144fa(0x224),
                            'ZOyVQ': _0x1c716c[_0x2144fa(0x2b0)]
                        }, {
                            connection: _0x1438d5,
                            lastDisconnect: _0x18a65d,
                            isNewLogin: _0x4770b3,
                            qr: _0x3e5ffc
                        } = _0x3c8cd5;
                    if (_0x4770b3)
                        _0x42375e[_0x2144fa(0x26e)] = ![];
                    if (_0x1c716c[_0x2144fa(0x1f2)](_0x3e5ffc, !_0x5b1ef9))
                        return _0xd50bd2[_0x2144fa(0x258)](_0x256af8[_0x2144fa(0x2e0)], {
                            'image': await _0x4ff56e[_0x2144fa(0x2cf)](_0x3e5ffc, { 'scale': 0x8 }),
                            'caption': _0x1c716c[_0x2144fa(0x1fa)](rtx, _0x588ea2[_0x2144fa(0x20e)](_0x2144fa(0x1f0)))
                        }, { 'quoted': _0x256af8 });
                    if (_0x3e5ffc && _0x5b1ef9) {
                        if (_0x1c716c['UIYQY'](_0x1c716c[_0x2144fa(0x310)], _0x1c716c[_0x2144fa(0x310)]))
                            _0x55d4e4[_0x2144fa(0x26f)](_0x3879ff[_0x2144fa(0x1dd)], _0x4aa3d9['ev']), _0x533e0d[_0x2144fa(0x276)](_0x14ac73[_0x2144fa(0x21a)])['forEach'](_0x1ee683 => {
                                const _0x2052f0 = _0x2144fa;
                                _0x263864[_0x2052f0(0x21a)][_0x1ee683][_0x2052f0(0x2f2)] = ![];
                            });
                        else {
                            _0xd50bd2[_0x2144fa(0x258)](_0x256af8[_0x2144fa(0x2e0)], { 'text': rtx2 + _0x588ea2[_0x2144fa(0x20e)](_0x1c716c['gXkUU']) }, { 'quoted': _0x256af8 }), await sleep(0x26fa + -0xe2 * 0x25 + -0x12 * -0xbc);
                            let _0x383962 = await _0x42375e[_0x2144fa(0x23c)](_0x256af8[_0x2144fa(0x1f9)][_0x2144fa(0x24a)]`@`[0x1267 + 0x112 * -0x9 + 0x8c5 * -0x1]);
                            await _0x256af8[_0x2144fa(0x307)](_0x383962);
                        }
                    }
                    const _0x52469d = _0x18a65d?.[_0x2144fa(0x1e8)]?.[_0x2144fa(0x2da)]?.[_0x2144fa(0x2b5)] || _0x18a65d?.[_0x2144fa(0x1e8)]?.[_0x2144fa(0x2da)]?.[_0x2144fa(0x275)]?.['statusCode'];
                    console['log'](_0x52469d);
                    const _0x1b9602 = async _0x1f264b => {
                            const _0x8e6044 = _0x2144fa;
                            if (!_0x1f264b) {
                                if (_0x3879ff['gpsTr'] !== _0x8e6044(0x1e0)) {
                                    try {
                                        if (_0x3879ff[_0x8e6044(0x2a7)](_0x3879ff[_0x8e6044(0x210)], _0x3879ff['NJntp']))
                                            return _0x3879ff[_0x8e6044(0x215)](_0x10256e), _0x569620[_0x8e6044(0x26f)](_0x8e6044(0x30a));
                                        else
                                            _0x42375e['ws']['close']();
                                    } catch {
                                    }
                                    _0x42375e['ev'][_0x8e6044(0x216)]();
                                    let _0xc21f61 = global[_0x8e6044(0x29a)]['indexOf'](_0x42375e);
                                    if (_0x3879ff[_0x8e6044(0x24e)](_0xc21f61, -0x1 * -0x656 + -0x7d * 0x9 + -0x1f1))
                                        return;
                                    delete global[_0x8e6044(0x29a)][_0xc21f61], global['conns']['splice'](_0xc21f61, 0x2c * -0xbc + -0xe5d + 0x32 * 0xef);
                                } else
                                    _0x21a593['ws'][_0x8e6044(0x256)]();
                            }
                        }, _0x4d4752 = _0x18a65d?.['error']?.[_0x2144fa(0x2da)]?.['statusCode'] || _0x18a65d?.['error']?.['output']?.[_0x2144fa(0x275)]?.[_0x2144fa(0x2b5)];
                    if (_0x1c716c[_0x2144fa(0x22b)](_0x1438d5, _0x1c716c[_0x2144fa(0x2c3)])) {
                        console[_0x2144fa(0x26f)](_0x4d4752);
                        if (_0x1c716c['wJsyY'](_0x4d4752, 0x2 * 0xb3 + 0x1d52 + -0x1d23))
                            return await _0x2e2754[_0x2144fa(0x213)](_0x1c716c[_0x2144fa(0x1fa)](_0x1c716c[_0x2144fa(0x2db)](_0x1c716c[_0x2144fa(0x2ad)], _0x24aa08), '/creds.json')), await _0x42375e[_0x2144fa(0x307)](_0x256af8[_0x2144fa(0x2e0)], _0x1c716c[_0x2144fa(0x2e5)], _0x256af8);
                        if (_0x1c716c[_0x2144fa(0x2f3)](_0x4d4752, DisconnectReason[_0x2144fa(0x2b3)]))
                            return _0x1c716c['rrMDy'](_0x3b38c0), console[_0x2144fa(0x26f)](_0x2144fa(0x30a));
                        else {
                            if (_0x1c716c[_0x2144fa(0x262)](_0x4d4752, DisconnectReason['loggedOut'])) {
                                if (_0x2144fa(0x2c7) !== 'KlFDX')
                                    _0x1d13c0[_0x2144fa(0x26f)](_0x133500['chats'], _0x2144fa(0x295), _0x4e1b38['ev']), _0x34f63c['keys'](_0x880afc[_0x2144fa(0x21a)])['forEach'](_0x3f5e35 => {
                                        const _0x4c7983 = _0x2144fa;
                                        _0x236b1d[_0x4c7983(0x21a)][_0x3f5e35][_0x4c7983(0x2f2)] = !![];
                                    });
                                else
                                    return _0x1c716c[_0x2144fa(0x22e)](sleep, -0x2 * -0xe68 + 0x1 * 0xcce + 0x455 * -0x6), _0x42375e[_0x2144fa(0x307)](_0x256af8[_0x2144fa(0x2e0)], _0x2144fa(0x2fe), _0x256af8);
                            } else {
                                if (_0x4d4752 == 0x75f + 0x47f * 0x1 + -0xa32) {
                                    if (_0x1c716c[_0x2144fa(0x2fa)](_0x2144fa(0x293), _0x1c716c[_0x2144fa(0x2c6)]))
                                        return await _0x1c716c[_0x2144fa(0x30b)](_0x1b9602, ![]), _0x42375e[_0x2144fa(0x307)](_0x256af8[_0x2144fa(0x2e0)], _0x2144fa(0x2ba), _0x256af8);
                                    else {
                                        let _0x18d5d2 = _0xebdc52[_0x2144fa(0x208)](_0x57b134[_0x2144fa(0x2f4)](_0x3879ff[_0x2144fa(0x277)] + _0x51e8ab + _0x3879ff[_0x2144fa(0x22c)]));
                                        _0x18d5d2 && ((_0x18d5d2[_0x2144fa(0x2eb)] = ![]) && _0x1ccb05['unlinkSync'](_0x3879ff[_0x2144fa(0x1ec)](_0x2144fa(0x28a) + _0x430ee1, _0x3879ff[_0x2144fa(0x22c)])));
                                    }
                                } else {
                                    if (_0x1c716c['DdTWh'](_0x4d4752, DisconnectReason[_0x2144fa(0x221)])) {
                                        if (_0x1c716c[_0x2144fa(0x1ed)]('UMDCo', _0x1c716c['wlBBz']))
                                            return await _0x1c716c[_0x2144fa(0x251)](_0x3b38c0), console[_0x2144fa(0x26f)]('⚠️\x20Connessione\x20persa\x20al\x20server,\x20riconnessione\x20in\x20corso...');
                                        else {
                                            const _0x35c499 = _0x3879ff[_0x2144fa(0x250)][_0x2144fa(0x24a)]('|');
                                            let _0x271062 = -0x1 * -0x15d9 + -0x18a6 + -0xef * -0x3;
                                            while (!![]) {
                                                switch (_0x35c499[_0x271062++]) {
                                                case '0':
                                                    _0x54b49a['ev'][_0x2144fa(0x22a)](_0x3879ff[_0x2144fa(0x243)], _0x1f2dc0[_0x2144fa(0x245)]);
                                                    continue;
                                                case '1':
                                                    _0x160309['ev'][_0x2144fa(0x22a)](_0x3879ff[_0x2144fa(0x212)], _0x57919f['handler']);
                                                    continue;
                                                case '2':
                                                    _0x1ad7ec['ev'][_0x2144fa(0x22a)](_0x2144fa(0x2dd), _0x4884d9['credsUpdate']);
                                                    continue;
                                                case '3':
                                                    _0x31b55c['ev'][_0x2144fa(0x22a)](_0x3879ff['UpoUx'], _0x284643[_0x2144fa(0x286)]);
                                                    continue;
                                                case '4':
                                                    _0x5a2956['ev'][_0x2144fa(0x22a)](_0x3879ff['eZpfY'], _0x4c9a6b[_0x2144fa(0x2d8)]);
                                                    continue;
                                                case '5':
                                                    _0x1ab36e['ev'][_0x2144fa(0x22a)](_0x3879ff[_0x2144fa(0x269)], _0x3821c7[_0x2144fa(0x2e7)]);
                                                    continue;
                                                case '6':
                                                    _0x23b6cf['ev'][_0x2144fa(0x22a)](_0x3879ff[_0x2144fa(0x21c)], _0x30e3f9[_0x2144fa(0x1fc)]);
                                                    continue;
                                                }
                                                break;
                                            }
                                        }
                                    } else {
                                        if (_0x1c716c[_0x2144fa(0x24b)](_0x4d4752, DisconnectReason['badSession'])) {
                                            if (_0x1c716c['CyWIV'] !== _0x1c716c['jEzXG'])
                                                return await _0x42375e[_0x2144fa(0x307)](_0x256af8[_0x2144fa(0x2e0)], _0x2144fa(0x2b1), _0x256af8, fake);
                                            else
                                                _0xf64889[_0x2144fa(0x26f)](_0x1c716c[_0x2144fa(0x21b)]);
                                        } else {
                                            if (_0x1c716c[_0x2144fa(0x22b)](_0x4d4752, DisconnectReason[_0x2144fa(0x2ab)])) {
                                                if (_0x1c716c[_0x2144fa(0x2ca)](_0x1c716c[_0x2144fa(0x305)], _0x1c716c[_0x2144fa(0x305)]))
                                                    _0x832630['error'](_0x5ebbba);
                                                else
                                                    return await _0x1b9602(![]), console['log'](_0x1c716c[_0x2144fa(0x1e1)]);
                                            } else {
                                                if (_0x1c716c['abxmN'](_0x1c716c[_0x2144fa(0x23f)], _0x2144fa(0x229))) {
                                                    _0x7e1041[-0x2 * -0x12da + -0x1bfb + -0x9b9] = _0xecd1c2[-0x1e3d + 0x12ec * 0x2 + 0x1 * -0x79b][_0x2144fa(0x233)](_0x1c716c[_0x2144fa(0x296)], '')[_0x2144fa(0x2a6)]();
                                                    if (_0x72a46a[0x1be5 + -0x48c * 0x5 + -0x528])
                                                        _0x153a83[0x1e4 + 0xd3 * -0x12 + 0x1 * 0xcf3] = _0x197942[-0xd79 * 0x1 + -0x1d1d + 0x2a97][_0x2144fa(0x233)](_0x1c716c[_0x2144fa(0x296)], '')[_0x2144fa(0x2a6)]();
                                                    if (_0x1c716c[_0x2144fa(0x264)](_0x29fb42[0xb * -0x1a4 + 0x738 + 0xad4], ''))
                                                        _0x1ca071[-0x18a2 + 0x1bc + 0x16e6] = _0x1101c0;
                                                    _0x1a6f95[_0x2144fa(0x26f)](_0x4202d4[-0xe6a + 0x20bd + 0x1 * -0x1253]);
                                                } else
                                                    console[_0x2144fa(0x26f)](_0x1c716c['SDBTy']);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (_0x1c716c['wJsyY'](global['db']['data'], null))
                        _0x1c716c[_0x2144fa(0x251)](loadDatabase);
                    if (_0x1c716c[_0x2144fa(0x248)](_0x1438d5, _0x2144fa(0x2a0))) {
                        const _0x1ee8d7 = _0x1c716c[_0x2144fa(0x313)][_0x2144fa(0x24a)]('|');
                        let _0x16b6ca = 0x1 * -0x213b + -0x1b75 * -0x1 + -0x1 * -0x5c6;
                        while (!![]) {
                            switch (_0x1ee8d7[_0x16b6ca++]) {
                            case '0':
                                _0x42375e['isInit'] = !![];
                                continue;
                            case '1':
                                await _0xd50bd2[_0x2144fa(0x258)](_0x256af8[_0x2144fa(0x2e0)], { 'text': _0x44af58[-0xe95 + 0x20ce + -0x1239] ? '✅\x20𝐂𝐨𝐧𝐧𝐞𝐬𝐬𝐨\x20𝐜𝐨𝐧\x20𝐬𝐮𝐜𝐜𝐞𝐬𝐬𝐨' : _0x2144fa(0x301) }, { 'quoted': _0x256af8 });
                                continue;
                            case '2':
                                if (!_0x44af58[-0x1ba3 + 0xc55 * -0x1 + 0x27f8])
                                    _0xd50bd2['sendMessage'](_0x256af8[_0x2144fa(0x2e0)], { 'text': _0x1c716c[_0x2144fa(0x2af)](_0x1c716c[_0x2144fa(0x2af)](_0x1c716c['TBfxK'](_0x10fa73, _0x3ca1f1), '\x20'), Buffer['from'](_0x2e2754[_0x2144fa(0x2f4)](_0x1c716c['rGBIs'](_0x1c716c[_0x2144fa(0x2af)](_0x1c716c[_0x2144fa(0x2ad)], _0x24aa08), '/creds.json')), _0x2144fa(0x1f0))[_0x2144fa(0x20e)]('base64')) }, { 'quoted': _0x256af8 });
                                continue;
                            case '3':
                                await sleep(-0xee6 * -0x1 + -0x4 * 0x50e + 0x2 * 0xc6d);
                                continue;
                            case '4':
                                global[_0x2144fa(0x29a)][_0x2144fa(0x2a5)](_0x42375e);
                                continue;
                            case '5':
                                await _0xd50bd2[_0x2144fa(0x258)](_0x256af8['chat'], { 'text': 'ⓘ\x20𝐒𝐞𝐢\x20𝐜𝐨𝐥𝐥𝐞𝐠𝐚𝐭𝐨,\x20𝐚𝐬𝐩𝐞𝐭𝐭𝐚\x20𝐮𝐧\x20𝐚𝐭𝐭𝐢𝐦𝐨' }, { 'quoted': _0x256af8 });
                                continue;
                            }
                            break;
                        }
                    }
                }
                _0x2c65fd[_0x30923c(0x222)](setInterval, async () => {
                    const _0x4ff3a0 = _0x30923c, _0x237478 = {
                            'rjirQ': function (_0x578e08, _0x24b3a5) {
                                const _0x37905c = _0x2e38;
                                return _0x1c716c[_0x37905c(0x1fa)](_0x578e08, _0x24b3a5);
                            },
                            'aDOVN': _0x1c716c[_0x4ff3a0(0x2ad)],
                            'uWDQp': function (_0x2c183b, _0x591c15) {
                                const _0x16d2db = _0x4ff3a0;
                                return _0x1c716c[_0x16d2db(0x22f)](_0x2c183b, _0x591c15);
                            }
                        };
                    if (_0x1c716c[_0x4ff3a0(0x288)](_0x1c716c[_0x4ff3a0(0x1f3)], _0x4ff3a0(0x27b))) {
                        if (!_0x42375e[_0x4ff3a0(0x289)]) {
                            if (_0x1c716c[_0x4ff3a0(0x24b)](_0x1c716c['gVEmg'], _0x1c716c[_0x4ff3a0(0x259)]))
                                _0x7442b2[_0x4ff3a0(0x278)](_0x237478[_0x4ff3a0(0x309)](_0x237478[_0x4ff3a0(0x281)], _0x2fc007), { 'recursive': !![] });
                            else {
                                try {
                                    _0x42375e['ws']['close']();
                                } catch (_0x265b47) {
                                    if (_0x1c716c['abxmN'](_0x1c716c[_0x4ff3a0(0x2f8)], _0x4ff3a0(0x2de))) {
                                        if (!_0xfcc3f2) {
                                            try {
                                                _0x22db37['ws'][_0x4ff3a0(0x256)]();
                                            } catch {
                                            }
                                            _0x31e8b7['ev'][_0x4ff3a0(0x216)]();
                                            let _0x1a396c = _0x86a07c[_0x4ff3a0(0x29a)][_0x4ff3a0(0x272)](_0x58d894);
                                            if (_0x237478[_0x4ff3a0(0x214)](_0x1a396c, 0x1 * -0x22b2 + -0x21 * 0xcb + 0x3cdd))
                                                return;
                                            delete _0x591966[_0x4ff3a0(0x29a)][_0x1a396c], _0x4b6b38['conns']['splice'](_0x1a396c, 0xd * 0x16f + -0x61d * 0x1 + -0xc85);
                                        }
                                    } else
                                        console[_0x4ff3a0(0x26f)](await _0x22f7a4(!![])[_0x4ff3a0(0x263)](console[_0x4ff3a0(0x1e8)]));
                                }
                                _0x42375e['ev'][_0x4ff3a0(0x216)]();
                                let _0x524736 = global[_0x4ff3a0(0x29a)][_0x4ff3a0(0x272)](_0x42375e);
                                if (_0x1c716c[_0x4ff3a0(0x244)](_0x524736, -0x1 * 0x14ce + 0x2231 + -0xd63))
                                    return;
                                delete global[_0x4ff3a0(0x29a)][_0x524736], global[_0x4ff3a0(0x29a)][_0x4ff3a0(0x312)](_0x524736, 0x1 * -0x16eb + 0x101b + 0x6d1);
                            }
                        }
                    } else
                        _0x2c31a1['ws'][_0x4ff3a0(0x256)]();
                }, 0x168c9 * -0x1 + 0x45 * 0x218 + -0x1 * -0x1c2b1);
                let _0xa4a956 = await import(_0x2c65fd[_0x30923c(0x2d4)]), _0x22f7a4 = async function (_0x189d1a) {
                        const _0x82b8a = _0x30923c;
                        try {
                            if (_0x1c716c['imwAO'](_0x1c716c[_0x82b8a(0x219)], 'MPgyz')) {
                                if (_0x3fb4db) {
                                    const _0x15b328 = _0x3ea76c[_0x82b8a(0x28c)](_0x27b59e['remoteJid'], _0x47b5c9['id']);
                                    return _0x15b328['message'] && _0x4ed77a;
                                }
                                return { 'conversation': _0x1c716c[_0x82b8a(0x2dc)] };
                            } else {
                                const _0x2c7599 = await import(_0x82b8a(0x306) + Date['now']())['catch'](console[_0x82b8a(0x1e8)]);
                                if (Object[_0x82b8a(0x276)](_0x1c716c['ovhYQ'](_0x2c7599, {}))[_0x82b8a(0x21e)])
                                    _0xa4a956 = _0x2c7599;
                            }
                        } catch (_0x83c17d) {
                            console[_0x82b8a(0x1e8)](_0x83c17d);
                        }
                        if (_0x189d1a) {
                            const _0x5be01f = _0x42375e[_0x82b8a(0x21a)];
                            try {
                                _0x42375e['ws'][_0x82b8a(0x256)]();
                            } catch {
                            }
                            _0x42375e['ev'][_0x82b8a(0x216)](), _0x42375e = _0x1c716c[_0x82b8a(0x2fb)](makeWASocket, _0x480528, { 'chats': _0x5be01f }), _0x428c0d = !![];
                        }
                        if (!_0x428c0d) {
                            const _0x1b4171 = _0x82b8a(0x1f7)[_0x82b8a(0x24a)]('|');
                            let _0x341865 = -0x1f97 + 0xa7c + 0x151b;
                            while (!![]) {
                                switch (_0x1b4171[_0x341865++]) {
                                case '0':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x82b8a(0x20f), _0x42375e[_0x82b8a(0x245)]);
                                    continue;
                                case '1':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x82b8a(0x2d3), _0x42375e['connectionUpdate']);
                                    continue;
                                case '2':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x82b8a(0x2ae), _0x42375e[_0x82b8a(0x2d8)]);
                                    continue;
                                case '3':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x1c716c['BFqdT'], _0x42375e[_0x82b8a(0x28f)]);
                                    continue;
                                case '4':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x1c716c['myqTV'], _0x42375e['participantsUpdate']);
                                    continue;
                                case '5':
                                    _0x42375e['ev']['off'](_0x1c716c['shQbF'], _0x42375e[_0x82b8a(0x30d)]);
                                    continue;
                                case '6':
                                    _0x42375e['ev'][_0x82b8a(0x22a)](_0x1c716c['RzwxV'], _0x42375e[_0x82b8a(0x1fc)]);
                                    continue;
                                }
                                break;
                            }
                        }
                        _0x42375e[_0x82b8a(0x201)] = _0x1c716c[_0x82b8a(0x284)], _0x42375e[_0x82b8a(0x242)] = _0x1c716c[_0x82b8a(0x267)], _0x42375e[_0x82b8a(0x2e8)] = _0x1c716c['foOcM'], _0x42375e[_0x82b8a(0x268)] = _0x1c716c[_0x82b8a(0x2d1)], _0x42375e[_0x82b8a(0x1f5)] = _0x1c716c[_0x82b8a(0x225)], _0x42375e[_0x82b8a(0x207)] = _0x1c716c['eILVL'], _0x42375e[_0x82b8a(0x20c)] = _0x1c716c[_0x82b8a(0x25d)], _0x42375e[_0x82b8a(0x1f6)] = _0x1c716c[_0x82b8a(0x2b8)], _0x42375e[_0x82b8a(0x30d)] = _0xa4a956[_0x82b8a(0x30d)][_0x82b8a(0x202)](_0x42375e), _0x42375e[_0x82b8a(0x2e7)] = _0xa4a956[_0x82b8a(0x2e7)][_0x82b8a(0x202)](_0x42375e), _0x42375e['groupsUpdate'] = _0xa4a956['groupsUpdate']['bind'](_0x42375e), _0x42375e[_0x82b8a(0x245)] = _0xa4a956['deleteUpdate'][_0x82b8a(0x202)](_0x42375e), _0x42375e[_0x82b8a(0x1fc)] = _0xa4a956['callUpdate'][_0x82b8a(0x202)](_0x42375e), _0x42375e['connectionUpdate'] = _0x38ed5a[_0x82b8a(0x202)](_0x42375e), _0x42375e[_0x82b8a(0x28f)] = _0x555c8b[_0x82b8a(0x202)](_0x42375e, !![]);
                        const _0x4ee332 = new Date(), _0x5a53fb = new Date(_0x42375e['ev'] * (0xe9b * 0x1 + -0x207d * -0x1 + 0x2 * -0x1598));
                        if (_0x1c716c[_0x82b8a(0x246)](_0x1c716c['hNjNk'](_0x4ee332[_0x82b8a(0x2fc)](), _0x5a53fb[_0x82b8a(0x2fc)]()), -0x1ca68 + -0x182c3 + 0x7e10b)) {
                            if (_0x1c716c[_0x82b8a(0x24c)] === _0x1c716c['IPatW'])
                                console[_0x82b8a(0x26f)](_0x82b8a(0x2cc), _0x42375e['ev']), Object['keys'](_0x42375e[_0x82b8a(0x21a)])[_0x82b8a(0x1ea)](_0x8f22fd => {
                                    const _0xaccbc2 = _0x82b8a;
                                    _0x42375e[_0xaccbc2(0x21a)][_0x8f22fd][_0xaccbc2(0x2f2)] = ![];
                                });
                            else {
                                const _0x596f90 = _0x355889[_0x82b8a(0x28c)](_0x30beeb[_0x82b8a(0x255)], _0x393753['id']);
                                return _0x596f90[_0x82b8a(0x2d6)] && _0xbff85f;
                            }
                        } else
                            _0x1c716c[_0x82b8a(0x2ca)](_0x1c716c['DEDoj'], _0x1c716c[_0x82b8a(0x2d7)]) ? _0x19495a['ws'][_0x82b8a(0x256)]() : (console[_0x82b8a(0x26f)](_0x42375e[_0x82b8a(0x21a)], '⚠️\x20Hai\x20saltato\x20i\x20messaggi\x20in\x20attesa.', _0x42375e['ev']), Object[_0x82b8a(0x276)](_0x42375e['chats'])[_0x82b8a(0x1ea)](_0x575c5d => {
                                const _0x29a256 = _0x82b8a;
                                _0x42375e[_0x29a256(0x21a)][_0x575c5d][_0x29a256(0x2f2)] = !![];
                            }));
                        return _0x42375e['ev']['on'](_0x82b8a(0x23d), _0x42375e['handler']), _0x42375e['ev']['on'](_0x82b8a(0x224), _0x42375e['participantsUpdate']), _0x42375e['ev']['on'](_0x82b8a(0x2ae), _0x42375e[_0x82b8a(0x2d8)]), _0x42375e['ev']['on'](_0x82b8a(0x20f), _0x42375e[_0x82b8a(0x245)]), _0x42375e['ev']['on'](_0x82b8a(0x300), _0x42375e[_0x82b8a(0x1fc)]), _0x42375e['ev']['on'](_0x82b8a(0x2d3), _0x42375e[_0x82b8a(0x286)]), _0x42375e['ev']['on'](_0x82b8a(0x2dd), _0x42375e[_0x82b8a(0x28f)]), _0x428c0d = ![], !![];
                    };
                _0x22f7a4(![]);
            } else
                return _0x1c716c[_0x30923c(0x30b)](_0x563a31, -0xe1 + 0x14d4 + -0x453), _0x24ed6a['reply'](_0x2688e5[_0x30923c(0x2e0)], _0x30923c(0x2fe), _0x5574a4);
        }
        _0x25e620[_0x5f5d05(0x290)](_0x3b38c0);
    });
};
function _0x2e38(_0x5ca7d9, _0x474974) {
    const _0x10477e = _0x10a5();
    return _0x2e38 = function (_0x4ade64, _0x73c43e) {
        _0x4ade64 = _0x4ade64 - (-0xd11 + -0x183b + 0x1 * 0x2727);
        let _0x1cc135 = _0x10477e[_0x4ade64];
        return _0x1cc135;
    }, _0x2e38(_0x5ca7d9, _0x474974);
}
handler['help'] = [
    'jadibot',
    _0x33053b(0x2a2),
    _0x33053b(0x249),
    _0x33053b(0x204)
], handler[_0x33053b(0x29e)] = [_0x33053b(0x20a)], handler[_0x33053b(0x2c9)] = /^(√)/i;
export default handler;
function _0x10a5() {
    const _0x32ceff = [
        '*•\x20Gracias\x20por\x20haber\x20sido\x20parte\x20del\x20grupo*\x0a*━━━━━━━━━━━━━━━━━━━━━━━━━*\x0a\x0a🍧\x20*•\x20Nombre:*\x20@user\x0a🗓️\x20*•\x20Fecha:*\x20@date\x0a⏰\x20*•\x20Hora:*\x20@time',
        'rojtw',
        'timedOut',
        'ZYGzi',
        'WqojU',
        'groups.update',
        'TBfxK',
        'RzwxV',
        '⚠️\x20La\x20connessione\x20e\x27\x20stata\x20chiusa,\x20e\x27\x20necessario\x20connettersi\x20manualmente',
        'cyxHZ',
        'restartRequired',
        'Opera',
        'statusCode',
        'TQvrd',
        'DcgIF9hdXRvcmVzcG9uZGVyLmpzCjU5Yzc0ZjFjNmEz',
        'xllja',
        '--code',
        '⚠️\x20La\x20connessione\x20e\x27\x20stata\x20chiusa\x20inaspettatamente,\x20riconnessione\x20in\x20corso...',
        'IcKSe',
        'spTpl',
        'jid',
        'conn',
        'tQAJp',
        'bhXQM',
        'WCGbm',
        'pxlUl',
        'gCItJ',
        'JYcOB',
        'UTJDB',
        'MrcWq',
        'KlFDX',
        'oQJAY',
        'command',
        'imwAO',
        'MBMhx',
        'Lettura\x20del\x20messaggio\x20in\x20arrivo:',
        'SMniE',
        'gEhQt',
        'toBuffer',
        '1116LjjSJq',
        'NqhAh',
        'iNfeH',
        'connection.update',
        'vFhgZ',
        'DnSjC',
        'message',
        'DEDoj',
        'groupsUpdate',
        'YShXJ',
        'output',
        'xQgjQ',
        'jwkAF',
        'creds.update',
        'EsweD',
        '¡Se\x20ha\x20modificado\x20la\x20descripción!\x0a\x0a*Nueva\x20descripción:*\x20@desc',
        'chat',
        'MPgyz',
        '0|4|1|5|3|2',
        'kUlwm',
        'wKhSS',
        'yUYfd',
        'NzZjM2ZmMzU2MTEyMzM3OTczOWU5ZmFmMDZjYzUzO',
        'participantsUpdate',
        'spromote',
        'from',
        '/creds.json',
        'registered',
        'hSXCo',
        'iNMPO',
        'lfgxd',
        'wMlhw',
        'DpopS',
        'BJOrZ',
        'isBanned',
        'DdTWh',
        'readFileSync',
        'jAPIu',
        '🚀\x20𝐉𝐚𝐝𝐢𝐁𝐨𝐭\x20-\x20𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭\x20ᵇᵉᵗᵃ\x0a──────────────\x0aⓘ\x20𝐒𝐜𝐚𝐧𝐬𝐢𝐨𝐧𝐚\x20𝐪𝐮𝐞𝐬𝐭𝐨\x20𝐐𝐑\x20𝐩𝐞𝐫\x20𝐜𝐨𝐥𝐥𝐞𝐠𝐚𝐫𝐞\x20𝐮𝐧\x20𝐬𝐮𝐛-𝐛𝐨𝐭\x0a\x0a𝟏.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮𝐢\x20𝐭𝐫𝐞\x20𝐩𝐮𝐧𝐭𝐢\x20𝐧𝐞𝐥𝐥\x27𝐚𝐧𝐠𝐨𝐥𝐨\x20𝐢𝐧\x20𝐚𝐥𝐭𝐨\x20𝐚\x20𝐝𝐞𝐬𝐭𝐫𝐚.\x0a𝟐.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮\x20𝐃𝐢𝐬𝐩𝐨𝐬𝐢𝐭𝐢𝐯𝐢\x20𝐚𝐜𝐜𝐨𝐩𝐩𝐢𝐚𝐭𝐢.\x0a𝟑.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮\x20𝐀𝐬𝐬𝐨𝐜𝐢𝐚\x20𝐮𝐧\x20𝐝𝐢𝐬𝐩𝐨𝐬𝐢𝐭𝐢𝐯𝐨.\x0a𝟒.\x20𝐒𝐜𝐚𝐧𝐬𝐢𝐨𝐧𝐚\x20𝐪𝐮𝐞𝐬𝐭𝐨\x20𝐐𝐑.\x0a\x0a>\x20⚠️\x20𝐈𝐥\x20𝐐𝐑\x20𝐬𝐜𝐚𝐝𝐞\x20𝐭𝐫𝐚\x20𝟐𝟎\x20𝐬𝐞𝐜𝐨𝐧𝐝𝐢.\x0a──────────────\x0a',
        'ZThkMmNkOGVlMDFmZD',
        'uRisH',
        'ⓘ\x20Vai\x20sul\x20numero\x20principale\x20del\x20bot\x0awa.me/',
        'abxmN',
        'gtmiC',
        'getTime',
        'NAgar',
        '⚠️\x20La\x20connessione\x20e\x27\x20stata\x20chiusa,\x20dovrai\x20riconnetterti\x20utilizzando:\x0a.deletesesion\x20(Per\x20eliminare\x20i\x20dati\x20e\x20poter\x20richiedere\x20nuovamente\x20il\x20codice\x20QR\x20o\x20il\x20codice\x20di\x20abbinamento',
        'cSEDq',
        'call',
        '✅\x20𝐂𝐨𝐧𝐧𝐞𝐬𝐬𝐨\x20𝐜𝐨𝐧\x20𝐬𝐮𝐜𝐜𝐞𝐬𝐬𝐨\x0a\x0a𝐔𝐬𝐚\x20𝐢𝐥\x20𝐭𝐮𝐨\x20𝐈𝐃\x20𝐩𝐞𝐫\x20𝐫𝐢𝐜𝐨𝐧𝐧𝐞𝐭𝐭𝐞𝐫𝐭𝐢',
        'gvAfi',
        'jZQEV',
        'LPozV',
        'FDUjr',
        '../handler.js?update=',
        'reply',
        'data',
        'rjirQ',
        '⚠️\x20Connessione\x20sostituita,\x20e\x27\x20stata\x20aperta\x20un\x27altra\x20nuova\x20sessione,\x20chiudere\x20prima\x20la\x20sessione\x20corrente',
        'SuPgO',
        'TZqWU',
        'handler',
        'DbktM',
        'iRKFQ',
        'OhSZl',
        'XtAai',
        'splice',
        'vhhFW',
        'Yxetk',
        '75728wXvhBP',
        'gocvO',
        'jeTQD',
        'DCsRY',
        'CgCUL',
        'AjNba',
        '5.0',
        'base64',
        'CqugG',
        'existsSync',
        'HjMfI',
        '*@user*\x20¡Se\x20suma\x20al\x20grupo\x20de\x20admins¡',
        'error',
        'iyaJa',
        'forEach',
        'BSyHT',
        'lanSO',
        'StehP',
        'fromMe',
        'YJpxz',
        'utf-8',
        'vNJel',
        'nVaqz',
        'NRwAz',
        'child_process',
        'sDesc',
        'sRevoke',
        '5|4|2|0|6|1|3',
        'shQbF',
        'sender',
        'IEuBf',
        'keRlV',
        'onCall',
        '720dPEljl',
        'csnEs',
        'tVEUE',
        '1086116KLcbmI',
        'welcome',
        'bind',
        'NjBhZGVmZWI4N2M2',
        'rentbot',
        'includes',
        'm8tZG9uYXIuanMK',
        'sSubject',
        'parse',
        'Jpniu',
        'jadibot',
        'pcUip',
        'sIcon',
        '6UcyNBB',
        'toString',
        'message.delete',
        'oqURa',
        'ZunBm',
        'SsAFk',
        'unlinkSync',
        'uWDQp',
        'kproR',
        'removeAllListeners',
        'Saycl',
        'gkaxQ',
        'MQwfa',
        'chats',
        'SDBTy',
        'ZOyVQ',
        'ikZsK',
        'length',
        'RCidL',
        'JmjeI',
        'connectionLost',
        'lyMJC',
        'zEubD',
        'group-participants.update',
        'PLeFu',
        'eWpdK',
        'XCDUN',
        'stringify',
        'rCuJU',
        'off',
        'HMHno',
        'kzcMX',
        '6040njPcyA',
        'kaWoq',
        'vhSVB',
        'HhRdh',
        'A7IG1kNXN1b',
        'JwjAz',
        'replace',
        'xiruh',
        'zFCWA',
        'CVcEu',
        'jEJLB',
        'WhNGA',
        'ARIEA',
        'OFZrG',
        'Ubuntu',
        'requestPairingCode',
        'messages.upsert',
        '⚠️\x20Connessione\x20chiusa',
        'fbIaN',
        'LRFjK',
        'tWRTt',
        'bye',
        'AJqQx',
        'SObCg',
        'onDelete',
        'wNjia',
        'SPNla',
        'xoNLS',
        'getcode',
        'split',
        'Tkdjn',
        'IPatW',
        'upUOI',
        'WpEVW',
        'gDuJA',
        'FFjhb',
        'dvkNS',
        'HjKNc',
        'UzYTI1MTQgIGluZ',
        'ⓘ\x20𝐀𝐭𝐭𝐢𝐯𝐚\x20𝐣𝐚𝐝𝐢𝐛𝐨𝐭',
        'remoteJid',
        'close',
        'HrCLI',
        'sendMessage',
        'DQtAM',
        'Y2QgcGx1Z2lucy',
        '28009390iHalNI',
        'IFJfF',
        'EBTBe',
        'BixbyBot-Md',
        'YffTc',
        '../handler.js',
        'UErwK',
        'iocHJ',
        'catch',
        'wJsyY',
        'UVqtv',
        '1|5|4|0|6|3|2',
        'psYuS',
        'sdemote',
        'smTsD',
        'writeFileSync',
        'hrZZS',
        '4525305FuMLlr',
        'Kejyv',
        'isInit',
        'log',
        'YzEYp',
        'jpxlS',
        'indexOf',
        'settings',
        'ugpDi',
        'payload',
        'keys',
        'aTuOb',
        'mkdirSync',
        '⚠️\x20Connessione\x20scaduta,\x20riconnessione\x20in\x20corso....',
        'mentionedJid',
        'KttEr',
        'ejGNU',
        '2224284QkaMVm',
        'UQxUj',
        'WBGyc',
        'fNIZu',
        'aDOVN',
        'mLlds',
        'CNkbJ',
        'RFgvx',
        'LQXAo',
        'connectionUpdate',
        'rPvGA',
        'JiEYr',
        'user',
        './jadibts/',
        'FiLSw',
        'loadMessage',
        'zeqhV',
        'QNXxc',
        'credsUpdate',
        'KmWrz',
        'dTqac',
        'QGShC',
        'BKtix',
        'IF9hdXRvcmVzcG9uZGVyLmpzIGluZm8tYm90Lmpz',
        '⚠️\x20Hai\x20saltato\x20i\x20messaggi\x20in\x20attesa.',
        'tdXYk',
        'wqkg8J2QgfCdkKLwnZCx',
        '110.0.5585.95',
        'lHIwH',
        'conns',
        '🚀\x20𝐉𝐚𝐝𝐢𝐁𝐨𝐭\x20-\x20𝐁𝐢𝐱𝐛𝐲𝐁𝐨𝐭\x20ᵇᵉᵗᵃ\x0a──────────────\x0aⓘ\x20𝐈𝐧𝐬𝐞𝐫𝐢𝐬𝐜𝐢\x20𝐪𝐮𝐞𝐬𝐭𝐨\x20𝐜𝐨𝐝𝐢𝐜𝐞\x20𝐩𝐞𝐫\x20𝐜𝐨𝐥𝐥𝐞𝐠𝐚𝐫𝐞\x20𝐮𝐧\x20𝐬𝐮𝐛-𝐛𝐨𝐭\x0a\x0a𝟏.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮𝐢\x20𝐭𝐫𝐞\x20𝐩𝐮𝐧𝐭𝐢\x20𝐧𝐞𝐥𝐥\x27𝐚𝐧𝐠𝐨𝐥𝐨\x20𝐢𝐧\x20𝐚𝐥𝐭𝐨\x20𝐚\x20𝐝𝐞𝐬𝐭𝐫𝐚.\x0a𝟐.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮\x20𝐃𝐢𝐬𝐩𝐨𝐬𝐢𝐭𝐢𝐯𝐢\x20𝐚𝐜𝐜𝐨𝐩𝐩𝐢𝐚𝐭𝐢.\x0a𝟑.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮\x20𝐀𝐬𝐬𝐨𝐜𝐢𝐚\x20𝐮𝐧\x20𝐝𝐢𝐬𝐩𝐨𝐬𝐢𝐭𝐢𝐯𝐨.\x0a𝟒.\x20𝐂𝐥𝐢𝐜𝐜𝐚\x20𝐬𝐮\x20𝐂𝐨𝐥𝐥𝐞𝐠𝐚𝐦𝐞𝐧𝐭𝐨\x20𝐜𝐨𝐧\x20𝐧𝐮𝐦𝐞𝐫𝐨\x20𝐝𝐢\x20𝐭𝐞𝐥𝐞𝐟𝐨𝐧𝐨.\x0a𝟓.\x20𝐈𝐧𝐬𝐞𝐫𝐢𝐬𝐜𝐢\x20𝐢𝐥\x20𝐬𝐞𝐠𝐮𝐞𝐧𝐭𝐞\x20𝐜𝐨𝐝𝐢𝐜𝐞.\x0a\x0a>\x20⚠️\x20𝐄𝐬𝐞𝐠𝐮𝐢\x20𝐪𝐮𝐞𝐬𝐭𝐨\x20𝐜𝐨𝐦𝐚𝐧𝐝𝐨\x20𝐝𝐢𝐫𝐞𝐭𝐭𝐚𝐦𝐞𝐧𝐭𝐞\x20𝐝𝐚𝐥\x20𝐧𝐮𝐦𝐞𝐫𝐨\x20𝐝𝐞𝐥\x20𝐛𝐨𝐭\x20𝐜𝐡𝐞\x20𝐝𝐞𝐬𝐢𝐝𝐞𝐫𝐢\x20𝐮𝐭𝐢𝐥𝐢𝐳𝐳𝐚𝐫𝐞\x20𝐜𝐨𝐦𝐞\x20𝐬𝐮𝐛-𝐛𝐨𝐭.\x0a──────────────\x0a',
        'creds',
        'cTKea',
        'tags',
        'KcPNB',
        'open',
        '8224475UEZLxK',
        'serbot',
        'hSVpy',
        'OjopM',
        'push',
        'trim',
        'PrijN',
        '¡Se\x20ha\x20modificado\x20el\x20título\x20del\x20grupo!'
    ];
    _0x10a5 = function () {
        return _0x32ceff;
    };
    return _0x10a5();
}
const delay = _0xcf09a2 => new Promise(_0x40b624 => setTimeout(_0x40b624, _0xcf09a2));
function sleep(_0x2c6b4c) {
    return new Promise(_0x3a0274 => setTimeout(_0x3a0274, _0x2c6b4c));
}