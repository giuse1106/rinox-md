import 'os';
import 'util';
import 'human-readable';
import '@whiskeysockets/baileys';
import 'fs';
import 'perf_hooks';

let handler = async (_0x1ece27, { conn: _0x4d8805, usedPrefix: _0x2b0a49 }) => {
  
  let _0x2d215f = {
    'key': {
      'participants': "0@s.whatsapp.net",
      'fromMe': false,
      'id': 'Halo'
    },
    'message': {
      'locationMessage': {
        'name': "𝐌𝐞𝐧𝐮 𝐒𝐩𝐨𝐧𝐬𝐨𝐫  ",
        'jpegThumbnail': await (await fetch("https://qu.ax/cSqEs.jpg")).buffer(),
        'vcard': `BEGIN:VCARD
VERSION:3.0
N:;Unlimited;;;
FN:Unlimited
ORG:Unlimited
TITLE:
item1.TEL;waid=19709001746:+1 (970) 900-1746
item1.X-ABLabel:Unlimited
X-WA-BIZ-DESCRIPTION:ofc
X-WA-BIZ-NAME:Unlimited
END:VCARD`
      }
    },
    'participant': "0@s.whatsapp.net"
  };


  let _0x3f08c2 = `
━━━━━━━━━━━━━━━⚡️ 𝗔𝗥𝗠𝗬 𝗛𝗢𝗦𝗧𝗜𝗡𝗚 ⚡️━━━━━━━━━━━━━━━  

🌟 **𝗛𝗢𝗦𝗧𝗜𝗡𝗚 𝗩𝗣𝗦 𝗔𝗙𝗙𝗜𝗗𝗔𝗕𝗜𝗟𝗘, 𝗦𝗖𝗔𝗟𝗔𝗕𝗜𝗟𝗘 𝗘 𝗩𝗘𝗟𝗢𝗖𝗘!** 🌟  

Con **Army Hosting**, ottieni server VPS potenti e scalabili, perfetti per ogni tua esigenza. Approfitta dei nostri **super sconti esclusivi per abbonamenti più lunghi**!  

━━━━━━━━━━━━━💻 𝗣𝗟𝗔𝗡 𝗩𝗣𝗦: 𝗦𝗖𝗘𝗚𝗟𝗜 𝗜𝗟 𝗧𝗨𝗢! 💻━━━━━━━━━━━━━  

🔥 **𝗩𝗣𝗦 𝗦𝗧𝗔𝗥𝗧**  
✔️ **1 vCore** · **1 GB RAM** · **25 GB SSD** · **2 TB Bandwidth**  
- **1 mese:** 15 euro
- **2 mesi:** 25 euro
- **3 mesi:** 30 euro
- **6 mesi:** 50 euro
- **12 mesi:** 90 euro
- **24 mesi:** 180 euro
✅ **Perfetto per progetti leggeri e test iniziali.**

🔥 **𝗩𝗣𝗦 𝗕𝗔𝗦𝗜𝗖**  
✔️ **2 vCores** · **2 GB RAM** · **50 GB SSD** · **4 TB Bandwidth**  
- **1 mese:** 30 euro
- **2 mesi:** 50 euro
- **3 mesi:** 60 euro
- **6 mesi:** 110 euro
- **12 mesi:** 200 euro
- **24 mesi:** 380 euro
✅ **Ideale per bot di media complessità o siti web.**

🔥 **𝗩𝗣𝗦 𝗣𝗥𝗘𝗠𝗜𝗨𝗠**  
✔️ **4 vCores** · **4 GB RAM** · **100 GB SSD** · **6 TB Bandwidth**  
- **1 mese:** 35 euro
- **2 mesi:** 60 euro
- **3 mesi:** 70 euro
- **6 mesi:** 130 euro
- **12 mesi:** 240 euro
- **24 mesi:** 450 euro
✅ **Perfetto per progetti avanzati con alto traffico.**

🔥 **𝗩𝗣𝗦 𝗘𝗡𝗧𝗘𝗥𝗣𝗥𝗜𝗦𝗘**  
✔️ **6 vCores** · **8 GB RAM** · **250 GB SSD** · **8 TB Bandwidth**  
- **1 mese:** 70 euro
- **2 mesi:** 120 euro
- **3 mesi:** 140 euro
- **6 mesi:** 250 euro
- **12 mesi:** 480 euro
- **24 mesi:** 900 euro
✅ **La scelta definitiva per e grandi progetti!**

━━━━━━━━━━━━━📆 𝗤𝗨𝗔𝗡𝗧𝗢 𝗥𝗜𝗦𝗣𝗔𝗥𝗠𝗜? 📆━━━━━━━━━━━━━  

🎯 **𝗦𝗖𝗢𝗡𝗧𝗜 AUMENTATI PER RISPARMIARE ANCORA DI PIÙ!**  
Gli abbonamenti a lungo termine garantiscono un **risparmio straordinario* rispetto ai costi mensili standard.  

🎯 **𝗥𝗜𝗦𝗣𝗔𝗥𝗠𝗜 𝗦𝗨𝗟𝗟𝗔 𝗩𝗣𝗦 𝗣𝗥𝗘𝗠𝗜𝗨𝗠:**  
- **2 mesi:** Risparmi 10 euro (rispetto a 2x35 = 70 euro).  
- **3 mesi:** Risparmi 35 euro (rispetto a 3x35 = 105 euro).  
- **6 mesi:** Risparmi 80 euro (rispetto a 6x35 = 210 euro).  
- **12 mesi:** Risparmi 180 euro (rispetto a 12x35 = 420 euro).  
- **24 mesi:** Risparmi 390 euro (rispetto a 24x35 = 840 euro).  

🎯 **𝗘𝗦𝗘𝗠𝗣𝗜 𝗗𝗘𝗜 𝗥𝗜𝗦𝗣𝗔𝗥𝗠𝗜 𝗦𝗨𝗟𝗟𝗔 𝗩𝗣𝗦 𝗘𝗡𝗧𝗘𝗥𝗣𝗥𝗜𝗦𝗘:**  
- **2 mesi:** Risparmi 20 euro (rispetto a 2x70 = 140 euro).  
- **3 mesi:** Risparmi 70 euro (rispetto a 3x70 = 210 euro).  
- **6 mesi:** Risparmi 170 euro (rispetto a 6x70 = 420 euro).  
- **12 mesi:** Risparmi 360 euro (rispetto a 12x70 = 840 euro).  
- **24 mesi:** Risparmi 780 euro (rispetto a 24x70 = 1.680 euro).  

🎯 **𝗥𝗜𝗦𝗣𝗔𝗥𝗠𝗜 𝗦𝗨𝗟𝗟𝗔 𝗩𝗣𝗦 𝗦𝗧𝗔𝗥𝗧:**  
- **2 mesi:** Risparmi 5 euro (rispetto a 2x15 = 30 euro).  
- **3 mesi:** Risparmi 15 euro (rispetto a 3x15 = 45 euro).  
- **6 mesi:** Risparmi 40 euro (rispetto a 6x15 = 90 euro).  
- **12 mesi:** Risparmi 90 euro (rispetto a 12x15 = 180 euro).  
- **24 mesi:** Risparmi 180 euro (rispetto a 24x15 = 360 euro).  

**🔔 Blocco del prezzo:** Nessun aumento per tutta la durata del contratto.  
**📈 Priorità nell’assistenza:** Supporto tecnico dedicato per i clienti più fedeli.  

━━━━━━━━━━━━━⚙️ 𝗣𝗘𝗥𝗖𝗛𝗘́ 𝗔𝗥𝗠𝗬 𝗛𝗢𝗦𝗧𝗜𝗡𝗚? ⚙️━━━━━━━━━━━━━  
✔️ **Uptime garantito al 99.9%**  
✔️ **Server ottimizzati** per massime prestazioni.  
✔️ **Protezione avanzata** con firewall e anti-DDoS.  
✔️ Assistenza clienti **H24** per ogni esigenza.  

📩 **𝗔𝗧𝗧𝗜𝗩𝗔 𝗜𝗟 𝗧𝗨𝗢 𝗣𝗟𝗔𝗡 𝗢𝗥𝗔!**  
Con **Army Hosting**, trasforma i tuoi progetti con un servizio sicuro, scalabile e conveniente. Contattaci per attivare subito il tuo piano!  


*Per informazioni piu specifiche, clicca il pulsante " Mostra canale "
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ꙰ 𝟥𝟥𝟥 ꙰ 𝔹𝕆𝕋 ꙰
`;

  let _0x575cba = global.db.data.nomedelbot || " ꙰ 𝟥𝟥𝟥 ꙰ 𝔹𝕆𝕋 ꙰ ";
  
  await _0x4d8805.sendMessage(_0x1ece27.chat, {
    text: _0x3f08c2,
    contextInfo: {
      mentionedJid: _0x4d8805.parseMention(wm),
      forwardingScore: 1,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363379966417373@newsletter",
        serverMessageId: '',
        newsletterName: _0x575cba
      }
    }
  }, {
    quoted: _0x2d215f
  });
};

handler.help = ["menu"];
handler.tags = ['menu'];
handler.command = /^(sponsor)$/i;
handler.admin = true;
export default handler;

// Formattazione del tempo (il tempo non esiste per Youns perche lui è immortale)
function clockString(_0xd0d91e) {
  let _0x27c45a = Math.floor(_0xd0d91e / 3600000);
  let _0x42617d = Math.floor(_0xd0d91e / 60000) % 60;
  let _0x1bf8dc = Math.floor(_0xd0d91e / 1000) % 60;
  return [_0x27c45a, _0x42617d, _0x1bf8dc].map(_0x2d1849 => _0x2d1849.toString().padStart(2, '0')).join(':');
}
