function _0x3543(_0x594905, _0x4b05dc) {
    const _0x21f9f0 = _0x3748();
    return _0x3543 = function (_0xbbbbbf, _0xfb2020) {
        _0xbbbbbf = _0xbbbbbf - (-0x35 + 0x3b * 0x1a + -0x1 * 0x3d5);
        let _0x5a6ebb = _0x21f9f0[_0xbbbbbf];
        return _0x5a6ebb;
    }, _0x3543(_0x594905, _0x4b05dc);
}
const _0x4c8e85 = _0x3543;
(function (_0x7433b0, _0x525ea7) {
    const _0xe224bc = _0x3543, _0x58130c = _0x7433b0();
    while (!![]) {
        try {
            const _0x49524e = parseInt(_0xe224bc(0x215)) / (-0x4 * 0x727 + 0x132d * -0x2 + 0x229 * 0x1f) + -parseInt(_0xe224bc(0x23d)) / (-0x1 * 0x187b + 0x161 * 0xf + -0x3ce * -0x1) + parseInt(_0xe224bc(0x20a)) / (0x15d * -0xb + -0x1 * 0x2690 + 0x3592 * 0x1) * (parseInt(_0xe224bc(0x223)) / (0x702 * -0x1 + -0x2a * -0x7e + -0xda6)) + parseInt(_0xe224bc(0x29b)) / (0x26d * -0x3 + -0xa6f + 0x1 * 0x11bb) * (parseInt(_0xe224bc(0x2a7)) / (0x9e6 + -0x220e + 0x182e)) + -parseInt(_0xe224bc(0x2b4)) / (0x26f6 + -0x1163 + -0x158c) + -parseInt(_0xe224bc(0x1f6)) / (-0x96e + -0x103 * 0x2 + 0xb7c) + parseInt(_0xe224bc(0x23f)) / (-0x5 * 0x5a1 + -0x8e7 * -0x2 + 0x14c * 0x8);
            if (_0x49524e === _0x525ea7)
                break;
            else
                _0x58130c['push'](_0x58130c['shift']());
        } catch (_0x57b664) {
            _0x58130c['push'](_0x58130c['shift']());
        }
    }
}(_0x3748, -0x1 * -0x7f064 + -0x15412d + -0x1 * -0x18a89f));
let handler = async (_0x534187, {
    conn: _0x1226e2,
    usedPrefix: _0x1705f8,
    command: _0x13a6ba,
    args: _0x2dbd57,
    isOwner: _0x4b91af,
    isAdmin: _0x54956f,
    isROwner: _0x267760
}) => {
    const _0x2eaf59 = _0x3543, _0xd70231 = {
            'KiwTJ': function (_0x5123d8, _0x1e59ea) {
                return _0x5123d8 || _0x1e59ea;
            },
            'hPFHs': 'admin',
            'NKBie': _0x2eaf59(0x27b),
            'ImBGp': function (_0x130e2a, _0x30caf6) {
                return _0x130e2a || _0x30caf6;
            },
            'XMFjm': function (_0x3b8c7a, _0x28c0c1) {
                return _0x3b8c7a || _0x28c0c1;
            },
            'sXSnh': _0x2eaf59(0x1f4),
            'zGYUS': function (_0x22b27a, _0x3d149f) {
                return _0x22b27a || _0x3d149f;
            },
            'uSutC': _0x2eaf59(0x284),
            'NnCsU': _0x2eaf59(0x262),
            'kCQIr': _0x2eaf59(0x1f7),
            'uBzgr': _0x2eaf59(0x22d),
            'PSUiR': _0x2eaf59(0x203),
            'yfbXc': '𝐦𝐨𝐝𝐨𝐚𝐝𝐦𝐢𝐧',
            'Jkfht': _0x2eaf59(0x211),
            'bYUVd': _0x2eaf59(0x232),
            'dXooR': function (_0x102281, _0x473d6a) {
                return _0x102281 === _0x473d6a;
            },
            'iKeiu': _0x2eaf59(0x2a4),
            'PnQde': 'detect',
            'PguIs': _0x2eaf59(0x280),
            'IYeTW': _0x2eaf59(0x241),
            'WDwRG': _0x2eaf59(0x204),
            'ZYWpb': function (_0x598205, _0x463d4a) {
                return _0x598205 || _0x463d4a;
            },
            'GcZkW': _0x2eaf59(0x285),
            'eXnrH': _0x2eaf59(0x299),
            'ZhdBm': function (_0x478dc0, _0x414bf5) {
                return _0x478dc0 || _0x414bf5;
            },
            'jBVSj': function (_0x40eeee, _0x2ffde6) {
                return _0x40eeee !== _0x2ffde6;
            },
            'tuZdA': _0x2eaf59(0x226),
            'DxnJN': _0x2eaf59(0x298),
            'AYBJi': 'aUmCC',
            'LOmGK': _0x2eaf59(0x2a1),
            'PNUAX': _0x2eaf59(0x247),
            'UVQrD': _0x2eaf59(0x2a9),
            'RzuiP': _0x2eaf59(0x266),
            'cEwaq': _0x2eaf59(0x264),
            'ieHIk': 'antilink',
            'MQHTE': function (_0x5d4606, _0x3f0635) {
                return _0x5d4606 || _0x3f0635;
            },
            'aEOEX': _0x2eaf59(0x283),
            'lQDrH': 'Rnond',
            'exnvm': _0x2eaf59(0x228),
            'vyRLE': _0x2eaf59(0x27f),
            'IQIyD': function (_0x4541a7, _0x322622) {
                return _0x4541a7 || _0x322622;
            },
            'OsbLm': _0x2eaf59(0x249),
            'hxUMw': function (_0xea2064, _0x2cc821) {
                return _0xea2064 || _0x2cc821;
            },
            'ZaPVi': 'ghoxO',
            'TIYFF': _0x2eaf59(0x2b5),
            'yQqSd': _0x2eaf59(0x259),
            'reelc': _0x2eaf59(0x261),
            'mBiNi': 'BZGTa',
            'lpuVz': 'audios',
            'khlDD': 'eFelA',
            'mvuMo': function (_0x23bb34, _0x4c5c30) {
                return _0x23bb34 || _0x4c5c30;
            },
            'wBMGu': 'owner',
            'jkdHI': _0x2eaf59(0x26a),
            'KrzhX': _0x2eaf59(0x2a5),
            'UbwXl': _0x2eaf59(0x2b1),
            'RbkZK': 'pconly',
            'NzPtJ': _0x2eaf59(0x268),
            'nkHvl': _0x2eaf59(0x234),
            'xDrAd': function (_0x1e559d, _0x3c53c5) {
                return _0x1e559d !== _0x3c53c5;
            },
            'bfrai': _0x2eaf59(0x1f5),
            'MwYgR': 'rqUJb',
            'mOfWc': _0x2eaf59(0x23a),
            'kHQWG': _0x2eaf59(0x27d),
            'WbaRm': _0x2eaf59(0x28a),
            'qgLNJ': _0x2eaf59(0x24e),
            'DFnLb': _0x2eaf59(0x23e),
            'YdYyW': _0x2eaf59(0x25e),
            'nreQb': function (_0x17ec95, _0x190d2a) {
                return _0x17ec95 !== _0x190d2a;
            },
            'rXkMW': _0x2eaf59(0x25a),
            'eBFUF': 'gpt',
            'bLtCe': 'KmcFi',
            'DYBJY': _0x2eaf59(0x256),
            'KnMTl': _0x2eaf59(0x26e),
            'fuyLc': function (_0x5c98f6, _0x210454) {
                return _0x5c98f6 || _0x210454;
            },
            'Xhgjc': _0x2eaf59(0x279),
            'AEUfo': function (_0x431246, _0x1716b6) {
                return _0x431246 || _0x1716b6;
            },
            'YHFXm': function (_0x13db43, _0x879fbc) {
                return _0x13db43 === _0x879fbc;
            },
            'yKJIZ': _0x2eaf59(0x22b),
            'QgkDl': 'VthfA',
            'nNhTL': _0x2eaf59(0x281),
            'TIqJg': function (_0x3dcf08, _0x315914) {
                return _0x3dcf08 !== _0x315914;
            },
            'KTaTT': _0x2eaf59(0x20f),
            'lxJkK': function (_0x1b94b4, _0x3d1fe7) {
                return _0x1b94b4 || _0x3d1fe7;
            },
            'VIaau': _0x2eaf59(0x233),
            'ZMLrB': function (_0x661c15, _0x4dc5c8) {
                return _0x661c15 || _0x4dc5c8;
            },
            'ixOrM': _0x2eaf59(0x28c),
            'RoRGh': _0x2eaf59(0x269),
            'JgXEM': 'Halo',
            'BlYZj': _0x2eaf59(0x225),
            'XSOEn': _0x2eaf59(0x200),
            'yploR': function (_0x58fa1c, _0x43c53e) {
                return _0x58fa1c(_0x43c53e);
            }
        }, _0x42342c = ('>\x20𝐃𝐢𝐠𝐢𝐭𝐚\x20' + _0x1705f8 + '𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐢\x20𝐩𝐞𝐫\x20𝐥𝐚\x20𝐥𝐢𝐬𝐭𝐚\x20𝐝𝐞𝐥𝐥𝐞\x20𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐢\x20𝐚𝐭𝐭𝐢𝐯𝐚𝐛𝐢𝐥𝐢\x20/\x20𝐝𝐢𝐬𝐚𝐭𝐭𝐢𝐯𝐚𝐛𝐢𝐥𝐢\x20')[_0x2eaf59(0x257)](), _0x25b2a5 = [{
                'title': null,
                'rows': [
                    {
                        'title': _0xd70231[_0x2eaf59(0x24d)],
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x232)
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x216)],
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x251)
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x2a8)],
                        'description': null,
                        'rowId': _0x1705f8 + 'antilinkhard'
                    },
                    {
                        'title': _0x2eaf59(0x214),
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x249)
                    },
                    {
                        'title': _0x2eaf59(0x291),
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x2ac)
                    },
                    {
                        'title': '𝐚𝐧𝐭𝐢𝐞𝐥𝐢𝐦𝐢𝐧𝐚',
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x2a1)
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x24b)],
                        'description': null,
                        'rowId': _0x1705f8 + 'antiviewonce'
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x1f9)],
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x256)
                    },
                    {
                        'title': _0x2eaf59(0x26b),
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x28c)
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x277)],
                        'description': null,
                        'rowId': _0x1705f8 + _0x2eaf59(0x261)
                    },
                    {
                        'title': _0xd70231[_0x2eaf59(0x23b)],
                        'description': null,
                        'rowId': _0x1705f8 + 'autosticker'
                    }
                ]
            }];
    let _0x3bc8b4 = await _0x1226e2[_0x2eaf59(0x1fc)](_0x534187[_0x2eaf59(0x273)]), _0x282bce = 'Admin\x20' + _0x3bc8b4;
    const _0x306e1b = {
        'text': _0x2eaf59(0x2aa),
        'footer': null,
        'title': null,
        'buttonText': _0x282bce,
        'sections': _0x25b2a5
    };
    let _0x152cab = /true|Enable|attiva|(turn)?on|1/i['test'](_0x13a6ba), _0x2bc059 = global['db'][_0x2eaf59(0x29a)]['chats'][_0x534187['chat']], _0x1e8ae0 = global['db'][_0x2eaf59(0x29a)]['users'][_0x534187[_0x2eaf59(0x273)]], _0x3a892f = global['db'][_0x2eaf59(0x29a)][_0x2eaf59(0x210)][_0x1226e2['user'][_0x2eaf59(0x270)]] || {}, _0x582955 = (_0x2dbd57[0x1 * -0x2527 + 0x2 * -0xbca + 0x3cbb] || '')[_0x2eaf59(0x243)](), _0x56f892 = ![], _0x3d1320 = ![];
    switch (_0x582955) {
    case _0xd70231[_0x2eaf59(0x1ff)]:
        if (!_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0x4b91af) {
                global['dfail'](_0xd70231['NKBie'], _0x534187, _0x1226e2);
                throw ![];
            }
        } else {
            if (!_0x54956f) {
                if (_0xd70231[_0x2eaf59(0x20e)](_0xd70231[_0x2eaf59(0x202)], _0xd70231['iKeiu'])) {
                    global[_0x2eaf59(0x282)](_0x2eaf59(0x244), _0x534187, _0x1226e2);
                    throw ![];
                } else {
                    _0x2362a4[_0x2eaf59(0x282)](_0x2eaf59(0x244), _0x218cb0, _0x442a61);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x246)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x2ab)]:
        if (!_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0x4b91af) {
                if (_0xd70231['dXooR'](_0xd70231['PguIs'], _0xd70231[_0x2eaf59(0x286)])) {
                    if (!_0x2e7252) {
                        _0x547f28[_0x2eaf59(0x282)]('group', _0x5bd113, _0x33acf6);
                        throw ![];
                    }
                } else {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x242)], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        } else {
            if (!_0x54956f) {
                global['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x2ac)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x23c)]:
        if (_0x534187['isGroup']) {
            if (!_0xd70231['ZYWpb'](_0x54956f, _0x4b91af)) {
                global['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x204)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x22a)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231[_0x2eaf59(0x27c)](_0x54956f, _0x4b91af)) {
                if (_0x2eaf59(0x299) !== _0xd70231[_0x2eaf59(0x2ad)]) {
                    if (!_0xd70231[_0x2eaf59(0x290)](_0x3267f0, _0x2c15ab)) {
                        _0x2c089d[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x225538, _0xf89da9);
                        throw ![];
                    }
                } else {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x285)] = _0x152cab;
        break;
    case 'bestemmiometro':
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231['ZhdBm'](_0x54956f, _0x4b91af)) {
                if (_0xd70231['jBVSj'](_0xd70231[_0x2eaf59(0x2a6)], _0xd70231[_0x2eaf59(0x2a6)])) {
                    _0x1d4852[_0x2eaf59(0x282)](_0x2eaf59(0x244), _0x5a77d7, _0x2da88e);
                    throw ![];
                } else {
                    global[_0x2eaf59(0x282)](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x240)] = _0x152cab;
        break;
    case 'comandieseguiti':
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (_0xd70231[_0x2eaf59(0x20e)](_0x2eaf59(0x21b), _0xd70231[_0x2eaf59(0x229)])) {
                _0x599bf5[_0x2eaf59(0x282)](_0xd70231['hPFHs'], _0x25267d, _0x5ceb9a);
                throw ![];
            } else {
                if (!(_0x54956f || _0x4b91af)) {
                    if (_0xd70231[_0x2eaf59(0x267)] !== _0x2eaf59(0x22c)) {
                        _0x35fe70[_0x2eaf59(0x282)](_0x2eaf59(0x244), _0x47859e, _0x23a673);
                        throw ![];
                    } else {
                        global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                        throw ![];
                    }
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x28f)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x227)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!(_0x54956f || _0x4b91af)) {
                if (_0xd70231[_0x2eaf59(0x2a3)] === _0xd70231['UVQrD']) {
                    _0x8d3614[_0x2eaf59(0x282)](_0xd70231['NKBie'], _0x2a48b5, _0x3b9798);
                    throw ![];
                } else {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059['antielimina'] = !_0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x25c)]:
        _0x56f892 = !![];
        if (!_0x267760) {
            global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x263)], _0x534187, _0x1226e2);
            throw ![];
        }
        global['opts'][_0xd70231['cEwaq']] = !_0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x260)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231['MQHTE'](_0x54956f, _0x4b91af)) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x29c)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x2b6)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231['zGYUS'](_0x54956f, _0x4b91af)) {
                if (_0xd70231[_0x2eaf59(0x22f)](_0x2eaf59(0x27a), _0xd70231['lQDrH'])) {
                    global[_0x2eaf59(0x282)](_0x2eaf59(0x244), _0x534187, _0x1226e2);
                    throw ![];
                } else {
                    if (!(_0x17f6a6 || _0x4e0d52)) {
                        _0x595776['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x412fb2, _0x498e12);
                        throw ![];
                    }
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x258)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x276)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231[_0x2eaf59(0x25d)](_0x54956f, _0x4b91af)) {
                if (_0xd70231[_0x2eaf59(0x20e)](_0x2eaf59(0x27f), _0xd70231[_0x2eaf59(0x21d)])) {
                    global['dfail'](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                    throw ![];
                } else {
                    if (!_0xd70231[_0x2eaf59(0x25d)](_0x59d4a3, _0xd6ae7b)) {
                        _0x439976['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x27fbe5, _0x3b6079);
                        throw ![];
                    }
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x231)] = _0x152cab;
        break;
    case 'autosticker':
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231[_0x2eaf59(0x207)](_0x54956f, _0x4b91af)) {
                global[_0x2eaf59(0x282)](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x1fd)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x21f)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231[_0x2eaf59(0x26f)](_0x54956f, _0x4b91af)) {
                if (_0xd70231['jBVSj'](_0x2eaf59(0x208), _0xd70231[_0x2eaf59(0x2a0)])) {
                    global['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                } else {
                    _0x579335[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0xd4b99d, _0x3f5b75);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x205)] = _0x152cab;
        break;
    case _0xd70231['TIYFF']:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (_0xd70231[_0x2eaf59(0x22f)]('TPthi', _0xd70231['yQqSd'])) {
                if (!_0xd70231[_0x2eaf59(0x209)](_0x54956f, _0x4b91af)) {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                }
            } else {
                _0x2decf5['dfail'](_0xd70231['hPFHs'], _0x214659, _0x28b23c);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x2b5)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x248)]:
        if (_0x534187['isGroup']) {
            if (_0xd70231[_0x2eaf59(0x28b)] !== _0xd70231[_0x2eaf59(0x28b)]) {
                if (!_0xd70231[_0x2eaf59(0x27c)](_0x4eab34, _0x475cf8)) {
                    _0x962903[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x140d5b, _0x39052b);
                    throw ![];
                }
            } else {
                if (!(_0x54956f || _0x4b91af)) {
                    global['dfail'](_0x2eaf59(0x244), _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x261)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x293)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (_0xd70231[_0x2eaf59(0x22f)](_0x2eaf59(0x2b3), _0xd70231[_0x2eaf59(0x21c)])) {
                _0x33a00a[_0x2eaf59(0x282)](_0xd70231['sXSnh'], _0x426d45, _0x3c08f6);
                throw ![];
            } else {
                if (!_0xd70231['mvuMo'](_0x54956f, _0x4b91af)) {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059['audios'] = _0x152cab;
        break;
    case _0x2eaf59(0x254):
        _0x56f892 = !![];
        if (!_0x4b91af) {
            global['dfail'](_0xd70231[_0x2eaf59(0x20b)], _0x534187, _0x1226e2);
            throw ![];
        }
        _0x3a892f[_0x2eaf59(0x254)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x221)]:
        _0x56f892 = !![];
        if (!_0x4b91af) {
            if (_0xd70231[_0x2eaf59(0x21e)] !== _0x2eaf59(0x238)) {
                global[_0x2eaf59(0x282)](_0xd70231['wBMGu'], _0x534187, _0x1226e2);
                throw ![];
            } else {
                _0x176f86[_0x2eaf59(0x282)](_0xd70231['sXSnh'], _0x48792f, _0x5a4653);
                throw ![];
            }
        }
        _0x3a892f[_0x2eaf59(0x26a)] = _0x152cab;
        break;
    case 'autoread':
        _0x56f892 = !![];
        if (!_0x267760) {
            global['dfail'](_0x2eaf59(0x1f4), _0x534187, _0x1226e2);
            throw ![];
        }
        global[_0x2eaf59(0x1fb)][_0xd70231[_0x2eaf59(0x29e)]] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x29f)]:
    case _0x2eaf59(0x220):
        _0x56f892 = !![];
        if (!_0x267760) {
            global['dfail'](_0xd70231[_0x2eaf59(0x263)], _0x534187, _0x1226e2);
            throw ![];
        }
        global[_0x2eaf59(0x1fb)][_0xd70231[_0x2eaf59(0x29f)]] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x1fa)]:
    case _0xd70231[_0x2eaf59(0x29d)]:
        _0x56f892 = !![];
        if (!_0x267760) {
            if (_0xd70231[_0x2eaf59(0x201)](_0xd70231[_0x2eaf59(0x274)], _0xd70231[_0x2eaf59(0x253)])) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x263)], _0x534187, _0x1226e2);
                throw ![];
            } else {
                if (!_0xd70231['zGYUS'](_0x3a2c95, _0x4e2ce3)) {
                    _0x1b7256[_0x2eaf59(0x282)]('admin', _0x24446f, _0x23fe0a);
                    throw ![];
                }
            }
        }
        global['opts'][_0xd70231[_0x2eaf59(0x1fa)]] = _0x152cab;
        break;
    case _0xd70231['mOfWc']:
    case _0xd70231[_0x2eaf59(0x296)]:
        _0x56f892 = !![];
        if (!_0x267760) {
            global[_0x2eaf59(0x282)](_0x2eaf59(0x1f4), _0x534187, _0x1226e2);
            throw ![];
        }
        global[_0x2eaf59(0x1fb)]['swonly'] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x287)]:
        _0x56f892 = !![];
        if (!_0x267760) {
            if (_0xd70231['xDrAd'](_0xd70231[_0x2eaf59(0x26d)], _0xd70231[_0x2eaf59(0x294)])) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x263)], _0x534187, _0x1226e2);
                throw ![];
            } else {
                _0x3e0c80[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x3d3181, _0x17452a);
                throw ![];
            }
        }
        _0x3a892f[_0x2eaf59(0x224)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x28e)]:
        _0x56f892 = !![];
        if (!_0x267760) {
            if (_0xd70231[_0x2eaf59(0x218)](_0xd70231[_0x2eaf59(0x235)], _0xd70231[_0x2eaf59(0x235)])) {
                _0x2cfb1d['dfail'](_0xd70231[_0x2eaf59(0x222)], _0x351e07, _0x54c7a9);
                throw ![];
            } else {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x263)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x3a892f[_0x2eaf59(0x265)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x2a2)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (_0xd70231['bLtCe'] === _0xd70231[_0x2eaf59(0x278)]) {
                if (!(_0x54956f || _0x4b91af)) {
                    global[_0x2eaf59(0x282)](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                    throw ![];
                }
            } else {
                _0x40642f[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x263)], _0x1259d4, _0x54dfad);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x255)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x24c)]:
        if (_0x534187['isGroup']) {
            if (_0xd70231[_0x2eaf59(0x22f)](_0xd70231[_0x2eaf59(0x252)], _0xd70231[_0x2eaf59(0x252)])) {
                if (!_0x25b614) {
                    _0x2b7788[_0x2eaf59(0x282)](_0x2eaf59(0x27b), _0x4f5831, _0x12fdf7);
                    throw ![];
                }
            } else {
                if (!_0xd70231[_0x2eaf59(0x26c)](_0x54956f, _0x4b91af)) {
                    global[_0x2eaf59(0x282)](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x2af)] = _0x152cab;
        break;
    case 'risposte':
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!(_0x54956f || _0x4b91af)) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x28d)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x237)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231['AEUfo'](_0x54956f, _0x4b91af)) {
                if (_0xd70231[_0x2eaf59(0x275)](_0xd70231[_0x2eaf59(0x230)], _0xd70231[_0x2eaf59(0x2ae)])) {
                    if (!_0xd70231['XMFjm'](_0x11bd62, _0x28ddf5)) {
                        _0x14561d[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x1f992f, _0x46eff7);
                        throw ![];
                    }
                } else {
                    global['dfail'](_0x2eaf59(0x244), _0x534187, _0x1226e2);
                    throw ![];
                }
            }
        }
        _0x2bc059[_0x2eaf59(0x279)] = _0x152cab;
    case _0xd70231[_0x2eaf59(0x2b2)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!_0xd70231[_0x2eaf59(0x26c)](_0x54956f, _0x4b91af)) {
                global['dfail'](_0xd70231['hPFHs'], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x281)] = _0x152cab;
        break;
    case _0x2eaf59(0x250):
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (_0xd70231[_0x2eaf59(0x295)]('GbFfM', _0xd70231[_0x2eaf59(0x245)])) {
                if (!_0xd70231[_0x2eaf59(0x20d)](_0x54956f, _0x4b91af)) {
                    global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                    throw ![];
                }
            } else {
                _0x5d9032[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x43db83, _0x2e07b8);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x250)] = _0x152cab;
        break;
    case _0xd70231[_0x2eaf59(0x239)]:
        if (_0x534187['isGroup']) {
            if (!_0xd70231[_0x2eaf59(0x219)](_0x54956f, _0x4b91af)) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x233)] = _0x152cab;
    case _0xd70231[_0x2eaf59(0x271)]:
        if (_0x534187[_0x2eaf59(0x25b)]) {
            if (!(_0x54956f || _0x4b91af)) {
                global[_0x2eaf59(0x282)](_0xd70231[_0x2eaf59(0x222)], _0x534187, _0x1226e2);
                throw ![];
            }
        }
        _0x2bc059[_0x2eaf59(0x20c)] = _0x152cab;
        break;
    default:
        let _0x15ff44 = {
            'key': {
                'participants': _0xd70231[_0x2eaf59(0x212)],
                'fromMe': ![],
                'id': _0xd70231[_0x2eaf59(0x27e)]
            },
            'message': {
                'locationMessage': {
                    'name': _0xd70231[_0x2eaf59(0x272)],
                    'jpegThumbnail': fs[_0x2eaf59(0x289)](_0x2eaf59(0x288)),
                    'vcard': _0x2eaf59(0x21a)
                }
            },
            'participant': _0xd70231[_0x2eaf59(0x212)]
        };
        if (!/[01]/['test'](_0x13a6ba))
            return await _0x1226e2['sendMessage'](_0x534187[_0x2eaf59(0x1f8)], { 'text': _0x42342c }, { 'quoted': _0x15ff44 });
        throw ![];
    }
    let _0xd796cd = {
            'key': {
                'participants': _0xd70231[_0x2eaf59(0x212)],
                'fromMe': ![],
                'id': _0xd70231[_0x2eaf59(0x27e)]
            },
            'message': {
                'locationMessage': {
                    'name': _0xd70231[_0x2eaf59(0x217)],
                    'jpegThumbnail': await (await _0xd70231['yploR'](fetch, 'https://telegra.ph/file/de558c2aa7fc80d32b8c3.png'))[_0x2eaf59(0x24a)](),
                    'vcard': _0x2eaf59(0x21a)
                }
            },
            'participant': _0xd70231[_0x2eaf59(0x212)]
        }, _0x20fab7 = {
            'key': {
                'participants': _0xd70231[_0x2eaf59(0x212)],
                'fromMe': ![],
                'id': _0xd70231['JgXEM']
            },
            'message': {
                'locationMessage': {
                    'name': _0xd70231[_0x2eaf59(0x217)],
                    'jpegThumbnail': await (await _0xd70231['yploR'](fetch, _0x2eaf59(0x297)))[_0x2eaf59(0x24a)](),
                    'vcard': 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=15395490858:+1\x20(539)\x20549-0858\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD'
                }
            },
            'participant': _0xd70231['RoRGh']
        };
    _0x1226e2[_0x2eaf59(0x22e)](_0x534187[_0x2eaf59(0x1f8)], _0x2eaf59(0x2b0) + _0x582955 + '*', null, { 'quoted': _0x152cab ? _0x20fab7 : _0xd796cd });
};
handler[_0x4c8e85(0x206)] = [
    _0x4c8e85(0x236),
    _0x4c8e85(0x24f)
][_0x4c8e85(0x292)](_0x284db7 => _0x284db7 + _0x4c8e85(0x1fe)), handler[_0x4c8e85(0x213)] = [
    _0x4c8e85(0x27b),
    _0x4c8e85(0x25f)
], handler['command'] = /^((attiva|disabilita)|(turn)?[01])$/i;
export default handler;
function _0x3748() {
    const _0x23ea45 = [
        'KrzhX',
        'OsbLm',
        'soloprivato',
        'jkdHI',
        'hPFHs',
        '1710212AIgTux',
        'antiCall',
        '𝐂𝐨𝐦𝐚𝐧𝐝𝐨\x20𝐧𝐨𝐧\x20𝐭𝐫𝐨𝐯𝐚𝐭𝐨\x20✗',
        'gaxqC',
        'LOmGK',
        'antilinkhard',
        'DxnJN',
        'GcZkW',
        'zdYQR',
        'aUmCC',
        '𝐚𝐧𝐭𝐢𝐯𝐢𝐞𝐰𝐨𝐧𝐜𝐞',
        'reply',
        'jBVSj',
        'yKJIZ',
        'antilinkbase2',
        'benvenuto',
        'antiporno',
        'sologruppo',
        'rXkMW',
        'attiva',
        'Xhgjc',
        'GVHET',
        'VIaau',
        'swonly',
        'Jkfht',
        'WDwRG',
        '1773486kseBhH',
        'SiOhC',
        '13636845JhIvvd',
        'bestemmiometro',
        'Bdjpd',
        'NKBie',
        'toLowerCase',
        'admin',
        'KTaTT',
        'welcome',
        'yvNjy',
        'reelc',
        'antispam',
        'buffer',
        'uBzgr',
        'DYBJY',
        'uSutC',
        'xPnin',
        'disabilita',
        'antitelegram',
        'antilink',
        'KnMTl',
        'MwYgR',
        'restrict',
        'gpt',
        'antitrava',
        'trim',
        'antilinkbase',
        'mmESu',
        'fVNCy',
        'isGroup',
        'RzuiP',
        'ImBGp',
        'antiprivato',
        'owner',
        'ieHIk',
        'modoadmin',
        '𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤',
        'sXSnh',
        'self',
        'antiPrivate',
        'public',
        'AYBJi',
        'gconly',
        '0@s.whatsapp.net',
        'jadibot',
        '𝐚𝐧𝐭𝐢𝐩𝐚𝐤𝐢',
        'fuyLc',
        'qgLNJ',
        'OjsSu',
        'hxUMw',
        'jid',
        'ixOrM',
        'BlYZj',
        'sender',
        'bfrai',
        'YHFXm',
        'exnvm',
        'yfbXc',
        'bLtCe',
        'antiinsta',
        'oiDSR',
        'group',
        'XMFjm',
        'statusonly',
        'JgXEM',
        'PuHEB',
        'ODSvp',
        'antitiktok',
        'dfail',
        'antilinkgp',
        '𝐛𝐞𝐧𝐯𝐞𝐧𝐮𝐭𝐨',
        'chatgpt',
        'IYeTW',
        'WbaRm',
        './settings.png',
        'readFileSync',
        'anticall',
        'mBiNi',
        'antipaki',
        'risposte',
        'YdYyW',
        'comandieseguiti',
        'KiwTJ',
        '𝐝𝐞𝐭𝐞𝐜𝐭',
        'map',
        'lpuVz',
        'DFnLb',
        'TIqJg',
        'kHQWG',
        'https://telegra.ph/file/00edd0958c94359540a8f.png',
        'HwaAQ',
        'CqDUf',
        'data',
        '1447835RgzaXb',
        'antiLink',
        'nkHvl',
        'UbwXl',
        'RbkZK',
        'ZaPVi',
        'antielimina',
        'eBFUF',
        'PNUAX',
        'bjBzM',
        'UxMnO',
        'tuZdA',
        '6UzrVKw',
        'kCQIr',
        'wltnj',
        '\x0a𝐀𝐓𝐓𝐈𝐕𝐀/𝐃𝐈𝐒𝐀𝐓𝐓𝐈𝐕𝐀',
        'PnQde',
        'detect',
        'eXnrH',
        'QgkDl',
        'antiTraba',
        '>\x20𝐅𝐮𝐧𝐳𝐢𝐨𝐧𝐞\x20»\x20*',
        'autoread',
        'nNhTL',
        'eFelA',
        '8492113fGzRzL',
        'antiviewonce',
        'aEOEX',
        'rowner',
        'kwHvo',
        '898312TpOvaS',
        '𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤𝐡𝐚𝐫𝐝',
        'chat',
        'PSUiR',
        'NzPtJ',
        'opts',
        'getName',
        'autosticker',
        '<option>',
        'bYUVd',
        '𝐒𝐭𝐚𝐭𝐨\x20»',
        'xDrAd',
        'iKeiu',
        '𝐚𝐧𝐭𝐢𝐭𝐫𝐚𝐯𝐚',
        'delete',
        'antiSpam',
        'help',
        'IQIyD',
        'UdYzw',
        'ZhdBm',
        '3voADlc',
        'wBMGu',
        'antiArab',
        'lxJkK',
        'dXooR',
        'gvjVy',
        'settings',
        '𝐚𝐮𝐭𝐨𝐬𝐭𝐢𝐜𝐤𝐞𝐫',
        'RoRGh',
        'tags',
        '𝐚𝐧𝐭𝐢𝐬𝐩𝐚𝐦',
        '723248eiDltH',
        'NnCsU',
        'XSOEn',
        'nreQb',
        'ZMLrB',
        'BEGIN:VCARD\x0aVERSION:3.0\x0aN:;Unlimited;;;\x0aFN:Unlimited\x0aORG:Unlimited\x0aTITLE:\x0aitem1.TEL;waid=15395490858:+1\x20(539)\x20549-0858\x0aitem1.X-ABLabel:Unlimited\x0aX-WA-BIZ-DESCRIPTION:ofc\x0aX-WA-BIZ-NAME:Unlimited\x0aEND:VCARD',
        'aLYxN',
        'khlDD',
        'vyRLE'
    ];
    _0x3748 = function () {
        return _0x23ea45;
    };
    return _0x3748();
}