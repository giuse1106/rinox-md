import fs from 'fs'
import path from 'path'
import archiver from 'archiver'

const _fs = fs.promises

let handler = async (m, { text, usedPrefix, command, __dirname }) => {
    if (!text || text.trim() === '') {
        throw `
> 𝐔𝐭𝐢𝐥𝐢𝐳𝐳𝐨 : ${usedPrefix + command} <𝐧𝐨𝐦𝐞 𝐜𝐚𝐫𝐭𝐨𝐥𝐥𝐚>

📌 Esempio:
        ${usedPrefix}getfolder
`.trim()
    }

    // Percorso della cartella principale del bot (dove si trova il bot stesso)
    const botFolderPath = __dirname

    try {
        // Crea un file di output temporaneo per il .zip
        const zipPath = path.join(__dirname, 'bot_folder.zip')
        const output = fs.createWriteStream(zipPath)
        const archive = archiver('zip', {
            zlib: { level: 9 } // Livello di compressione massimo
        })

        // Gestisce errori di archiviazione
        archive.on('error', (err) => {
            throw err
        })

        // Pipe l'output dello stream
        archive.pipe(output)

        // Aggiungi l'intera cartella del bot (tutti i file e le cartelle all'interno)
        archive.directory(botFolderPath, false)

        // Finalizza l'archivio
        await archive.finalize()

        // Invia il file .zip
        await m.reply({
            file: fs.createReadStream(zipPath),
            filename: 'bot_folder.zip'
        })

        // Elimina il file .zip temporaneo
        await _fs.unlink(zipPath)

    } catch (err) {
        await m.reply(`⛔️ Errore: ${err}`)
    }
}

handler.help = ['folder'].map(v => `get${v}`)
handler.tags = ['owner']
handler.command = /^g(et)?folder$/i

handler.owner = true

export default handler